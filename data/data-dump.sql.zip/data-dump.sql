# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.7.23)
# Database: fiscalnote
# Generation Time: 2018-12-15 00:10:25 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table craft_assetindexdata
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetindexdata`;

CREATE TABLE `craft_assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `craft_assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `craft_assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_assets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assets`;

CREATE TABLE `craft_assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assets_filename_folderId_unq_idx` (`filename`,`folderId`),
  KEY `craft_assets_folderId_idx` (`folderId`),
  KEY `craft_assets_volumeId_idx` (`volumeId`),
  CONSTRAINT `craft_assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assets_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_assettransformindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assettransformindex`;

CREATE TABLE `craft_assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_assettransforms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assettransforms`;

CREATE TABLE `craft_assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `craft_assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categories`;

CREATE TABLE `craft_categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_categories_groupId_idx` (`groupId`),
  CONSTRAINT `craft_categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categories_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_categories` WRITE;
/*!40000 ALTER TABLE `craft_categories` DISABLE KEYS */;

INSERT INTO `craft_categories` (`id`, `groupId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(2,1,'2018-12-13 21:37:54','2018-12-13 21:37:54','67ff24ff-df39-4d4a-ac08-280e927e2b93'),
	(3,1,'2018-12-13 21:37:59','2018-12-13 21:37:59','0247a4f9-1ecf-4277-8232-5800b6d72923');

/*!40000 ALTER TABLE `craft_categories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_categorygroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categorygroups`;

CREATE TABLE `craft_categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_categorygroups_handle_unq_idx` (`handle`),
  KEY `craft_categorygroups_structureId_idx` (`structureId`),
  KEY `craft_categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_categorygroups` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups` DISABLE KEYS */;

INSERT INTO `craft_categorygroups` (`id`, `structureId`, `fieldLayoutId`, `name`, `handle`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,3,17,'Dev: Width','devWidth','2018-12-13 21:37:35','2018-12-13 21:37:35','6cd2a639-b0d8-4f53-9cee-b408537a87a7');

/*!40000 ALTER TABLE `craft_categorygroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_categorygroups_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categorygroups_sites`;

CREATE TABLE `craft_categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `craft_categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `craft_categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups_sites` DISABLE KEYS */;

INSERT INTO `craft_categorygroups_sites` (`id`, `groupId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,0,NULL,NULL,'2018-12-13 21:37:35','2018-12-13 21:37:35','76a15852-76a3-4a9c-baf6-f892a43be560');

/*!40000 ALTER TABLE `craft_categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_content`;

CREATE TABLE `craft_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_heroTitle` text,
  `field_heroDescription` text,
  `field_calloutImageAlignment` varchar(255) DEFAULT NULL,
  `field_calloutTitle` text,
  `field_calloutDescription` text,
  `field_calloutCtaText` text,
  `field_calloutCtaUrl` varchar(255) DEFAULT NULL,
  `field_ctaTitle` text,
  `field_ctaSubtitle` text,
  `field_ctaLinkText` text,
  `field_ctaLinkUrl` varchar(255) DEFAULT NULL,
  `field_logoName` text,
  `field_relatedProductDescription` text,
  `field_productIntroductionTitle` text,
  `field_productionIntroductionDescription` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_content_siteId_idx` (`siteId`),
  KEY `craft_content_title_idx` (`title`),
  CONSTRAINT `craft_content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_content` WRITE;
/*!40000 ALTER TABLE `craft_content` DISABLE KEYS */;

INSERT INTO `craft_content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_heroTitle`, `field_heroDescription`, `field_calloutImageAlignment`, `field_calloutTitle`, `field_calloutDescription`, `field_calloutCtaText`, `field_calloutCtaUrl`, `field_ctaTitle`, `field_ctaSubtitle`, `field_ctaLinkText`, `field_ctaLinkUrl`, `field_logoName`, `field_relatedProductDescription`, `field_productIntroductionTitle`, `field_productionIntroductionDescription`)
VALUES
	(1,1,1,NULL,'2018-12-11 18:44:42','2018-12-11 18:44:42','f0e73ed3-526a-45b3-b4ab-8db2b3aa8360',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(2,2,1,'Full','2018-12-13 21:37:54','2018-12-13 21:37:54','f62cce53-be38-44f8-bb2f-51910399cebf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(3,3,1,'1/2','2018-12-13 21:37:59','2018-12-13 21:37:59','cc2d6b52-d49e-4887-b10f-5daed4b85cd6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(4,4,1,'Test Entry','2018-12-14 21:59:37','2018-12-15 00:09:31','4400105d-cac8-44fc-a36a-11c678baa145',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `craft_content` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_craftidtokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_craftidtokens`;

CREATE TABLE `craft_craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craft_craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_craftidtokens` WRITE;
/*!40000 ALTER TABLE `craft_craftidtokens` DISABLE KEYS */;

INSERT INTO `craft_craftidtokens` (`id`, `userId`, `accessToken`, `expiryDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjIxNDk0N2ZiNzNkYmI0ZWY0YWM2NWQ4YjFhNzk3NjE3YWEzNmQ5N2ZhMDJiM2FmY2M5M2M3YmExYjU4Y2JiNGVjYmZmYzQ0ZDJkYmM0ZWUxIn0.eyJhdWQiOiI2RHZFcmE3ZXFSS0xZaWM5Zm92eUQyRldGall4UndabiIsImp0aSI6IjIxNDk0N2ZiNzNkYmI0ZWY0YWM2NWQ4YjFhNzk3NjE3YWEzNmQ5N2ZhMDJiM2FmY2M5M2M3YmExYjU4Y2JiNGVjYmZmYzQ0ZDJkYmM0ZWUxIiwiaWF0IjoxNTQ0NjMyNDI1LCJuYmYiOjE1NDQ2MzI0MjUsImV4cCI6MTU0NzIyNDQyNSwic3ViIjoiODk0MjAiLCJzY29wZXMiOlsicHVyY2hhc2VQbHVnaW5zIiwiZXhpc3RpbmdQbHVnaW5zIiwidHJhbnNmZXJQbHVnaW5MaWNlbnNlIiwiZGVhc3NvY2lhdGVQbHVnaW5MaWNlbnNlIl19.NssUwTGtdP7AC6RwOKR_Y2pyAnsYKZcgpesINAXVqNI_JdFpPV6ND5nMA7mFE2TSf2FE4fxMDtzwi5-HEu-APDLd8_sqnxkVtMIR8915QSuH6CTRz-fzSFjmmU_5bnpiUOS8OdJ2-DC0GPGKi96CBTTmW8jjL-OUSzzQu_A3tHE','2019-01-11 16:33:47','2018-12-12 16:33:47','2018-12-12 16:33:47','45cdf9fa-8600-4972-a0f5-2fa7c38fe914');

/*!40000 ALTER TABLE `craft_craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_deprecationerrors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_deprecationerrors`;

CREATE TABLE `craft_deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_elementindexsettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elementindexsettings`;

CREATE TABLE `craft_elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_elementindexsettings` WRITE;
/*!40000 ALTER TABLE `craft_elementindexsettings` DISABLE KEYS */;

INSERT INTO `craft_elementindexsettings` (`id`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'craft\\elements\\Category','{\"sourceOrder\":[[\"heading\",\"Configurations\"],[\"key\",\"group:1\"]],\"sources\":{\"group:1\":{\"tableAttributes\":[]}}}','2018-12-13 21:38:27','2018-12-13 21:38:27','8b46cc58-96e2-470f-a107-15cfc0b042b4'),
	(2,'craft\\elements\\Entry','{\"sourceOrder\":[[\"key\",\"*\"],[\"heading\",\"Pages\"],[\"key\",\"section:2\"],[\"key\",\"section:4\"],[\"heading\",\"Blocks\"],[\"key\",\"section:1\"],[\"key\",\"section:3\"],[\"key\",\"section:5\"],[\"key\",\"section:6\"],[\"heading\",\"\"]],\"sources\":{\"section:3\":{\"tableAttributes\":{\"1\":\"postDate\",\"2\":\"expiryDate\",\"3\":\"link\"}},\"section:4\":{\"tableAttributes\":{\"1\":\"postDate\",\"2\":\"expiryDate\",\"3\":\"link\"}}}}','2018-12-13 23:29:13','2018-12-13 23:29:13','6ce23f9b-1847-49f7-8283-e1451bd272ba');

/*!40000 ALTER TABLE `craft_elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_elements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elements`;

CREATE TABLE `craft_elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_elements_type_idx` (`type`),
  KEY `craft_elements_enabled_idx` (`enabled`),
  KEY `craft_elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  CONSTRAINT `craft_elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_elements` WRITE;
/*!40000 ALTER TABLE `craft_elements` DISABLE KEYS */;

INSERT INTO `craft_elements` (`id`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,'craft\\elements\\User',1,0,'2018-12-11 18:44:42','2018-12-11 18:44:42','8fb1daa2-d7d1-4670-a12e-f5f1b51b812f'),
	(2,17,'craft\\elements\\Category',1,0,'2018-12-13 21:37:54','2018-12-13 21:37:54','76d22bc2-c06f-4e28-bdf9-d5bf18eaaa5a'),
	(3,17,'craft\\elements\\Category',1,0,'2018-12-13 21:37:59','2018-12-13 21:37:59','df74c310-46e2-46da-855b-ebcf1fe4f393'),
	(4,6,'craft\\models\\EntryDraft',1,0,'2018-12-14 21:59:37','2018-12-15 00:09:31','b7b1724c-e2ef-4f41-b942-396c9c5f8fb6'),
	(6,2,'verbb\\supertable\\elements\\SuperTableBlockElement',1,0,'2018-12-14 21:59:37','2018-12-15 00:09:32','57fbce0c-9653-4c2a-9fc1-47939cde600b'),
	(7,29,'craft\\elements\\MatrixBlock',1,0,'2018-12-14 21:59:37','2018-12-15 00:09:32','69d7bf8a-1f94-4f49-ad81-760c10079924'),
	(8,29,'craft\\elements\\MatrixBlock',1,0,'2018-12-14 21:59:38','2018-12-15 00:09:32','db889b8c-aeb4-4195-80f8-3e872ceea769'),
	(9,29,'craft\\elements\\MatrixBlock',1,0,'2018-12-14 21:59:38','2018-12-15 00:09:32','fc712d2a-dfa1-4094-a0ac-0229ef80c121');

/*!40000 ALTER TABLE `craft_elements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_elements_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elements_sites`;

CREATE TABLE `craft_elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_elements_sites_siteId_idx` (`siteId`),
  KEY `craft_elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `craft_elements_sites_enabled_idx` (`enabled`),
  KEY `craft_elements_sites_uri_siteId_idx` (`uri`,`siteId`),
  CONSTRAINT `craft_elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_elements_sites` WRITE;
/*!40000 ALTER TABLE `craft_elements_sites` DISABLE KEYS */;

INSERT INTO `craft_elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,NULL,NULL,1,'2018-12-11 18:44:42','2018-12-11 18:44:42','6f221b3d-a001-4cfb-83b5-78e8c3199fc1'),
	(2,2,1,'full',NULL,1,'2018-12-13 21:37:54','2018-12-13 21:37:56','d8944396-f35d-4bba-8c29-da148579d4a8'),
	(3,3,1,'1-2',NULL,1,'2018-12-13 21:37:59','2018-12-13 21:38:01','8411556e-0512-4714-802a-cbaa7501b275'),
	(4,4,1,'gregs-entry','products/gregs-entry',1,'2018-12-14 21:59:37','2018-12-15 00:09:31','02c6d009-6735-4b75-b425-d978af9269f9'),
	(6,6,1,NULL,NULL,1,'2018-12-14 21:59:37','2018-12-15 00:09:32','7989bb63-98ca-476e-9983-83fe8d995439'),
	(7,7,1,NULL,NULL,1,'2018-12-14 21:59:37','2018-12-15 00:09:32','8b981945-37e1-4f2a-9320-1c405ef016b7'),
	(8,8,1,NULL,NULL,1,'2018-12-14 21:59:38','2018-12-15 00:09:32','b63f16bc-9c2f-4ea5-977b-397042f0b71b'),
	(9,9,1,NULL,NULL,1,'2018-12-14 21:59:38','2018-12-15 00:09:32','ccbbcf52-542f-4411-bb5c-f014de86856a');

/*!40000 ALTER TABLE `craft_elements_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entries`;

CREATE TABLE `craft_entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entries_postDate_idx` (`postDate`),
  KEY `craft_entries_expiryDate_idx` (`expiryDate`),
  KEY `craft_entries_authorId_idx` (`authorId`),
  KEY `craft_entries_sectionId_idx` (`sectionId`),
  KEY `craft_entries_typeId_idx` (`typeId`),
  CONSTRAINT `craft_entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_entries` WRITE;
/*!40000 ALTER TABLE `craft_entries` DISABLE KEYS */;

INSERT INTO `craft_entries` (`id`, `sectionId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(4,2,2,1,'2018-12-14 21:55:00',NULL,'2018-12-14 21:59:37','2018-12-15 00:09:32','95f97840-31cc-466d-b009-26a96f736fc8');

/*!40000 ALTER TABLE `craft_entries` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entrydrafts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entrydrafts`;

CREATE TABLE `craft_entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entrydrafts_sectionId_idx` (`sectionId`),
  KEY `craft_entrydrafts_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `craft_entrydrafts_siteId_idx` (`siteId`),
  KEY `craft_entrydrafts_creatorId_idx` (`creatorId`),
  CONSTRAINT `craft_entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_entrytypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entrytypes`;

CREATE TABLE `craft_entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) DEFAULT 'Title',
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_entrytypes_name_sectionId_unq_idx` (`name`,`sectionId`),
  UNIQUE KEY `craft_entrytypes_handle_sectionId_unq_idx` (`handle`,`sectionId`),
  KEY `craft_entrytypes_sectionId_idx` (`sectionId`),
  KEY `craft_entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_entrytypes` WRITE;
/*!40000 ALTER TABLE `craft_entrytypes` DISABLE KEYS */;

INSERT INTO `craft_entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,4,'Callouts','callouts',0,NULL,'{calloutHeadline}',1,'2018-12-13 17:25:55','2018-12-13 21:46:18','a36b067c-7098-42b2-9d8d-a9a674965c58'),
	(2,2,6,'Products','products',1,'Title',NULL,1,'2018-12-13 17:41:54','2018-12-14 21:59:33','2c0c908f-4b65-4e0b-8b15-164d01b52125'),
	(3,3,7,'CTAs','ctas',0,NULL,'{ctaTitle}',1,'2018-12-13 17:47:38','2018-12-13 21:46:29','cd670326-f017-42ac-9196-3187b56f739f'),
	(4,4,9,'Solutions','solutions',1,'Title',NULL,1,'2018-12-13 17:53:19','2018-12-13 23:26:53','60970ce9-ca80-45b5-a7b0-c6779edc21d1'),
	(5,5,19,'Logos','logos',0,NULL,'{logoName}',1,'2018-12-13 21:40:22','2018-12-13 22:02:02','2e6a4adf-5541-4d20-9b32-141ce03f9530'),
	(6,6,20,'Related Products','relatedProducts',1,'Title',NULL,1,'2018-12-13 21:43:32','2018-12-13 23:30:53','99cdb5c8-86c7-440c-9521-c9cab6acc7a4');

/*!40000 ALTER TABLE `craft_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entryversions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entryversions`;

CREATE TABLE `craft_entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `siteId` int(11) NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entryversions_sectionId_idx` (`sectionId`),
  KEY `craft_entryversions_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `craft_entryversions_siteId_idx` (`siteId`),
  KEY `craft_entryversions_creatorId_idx` (`creatorId`),
  CONSTRAINT `craft_entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entryversions_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_entryversions` WRITE;
/*!40000 ALTER TABLE `craft_entryversions` DISABLE KEYS */;

INSERT INTO `craft_entryversions` (`id`, `entryId`, `sectionId`, `creatorId`, `siteId`, `num`, `notes`, `data`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,4,2,1,1,1,'Published draft “Draft 1”.','{\"typeId\":\"2\",\"authorId\":\"1\",\"title\":\"Greg\'s Entry\",\"slug\":\"gregs-entry\",\"postDate\":1544824500,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"4\":[],\"3\":[],\"8\":{\"6\":{\"type\":\"1\",\"fields\":{\"sectionBlocks\":{\"7\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"text\":\"<p>Left side</p>\",\"width\":[\"3\"]}},\"8\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"text\":\"<p>Right side</p>\",\"width\":[\"3\"]}},\"9\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"text\":\"<p>All of it!!!</p>\",\"width\":[]}}}}}}}}','2018-12-14 21:59:57','2018-12-14 21:59:57','9268217e-ec75-45fa-aa84-426d7ede9be3'),
	(2,4,2,1,1,2,'','{\"typeId\":\"2\",\"authorId\":\"1\",\"title\":\"Greg\'s Entry\",\"slug\":\"gregs-entry\",\"postDate\":1544824500,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"4\":[],\"3\":[],\"8\":{\"6\":{\"type\":\"1\",\"fields\":{\"sectionBlocks\":{\"7\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"text\":\"<p>Left side</p>\",\"width\":[\"3\"]}},\"8\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"text\":\"<p>Right side</p>\",\"width\":[\"3\"]}},\"9\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"text\":\"<p>All of it!!!</p>\",\"width\":[\"2\"]}}}}}}}}','2018-12-14 22:19:19','2018-12-14 22:19:19','62134b4b-7212-42a0-bf8f-458c2cc3c9d6'),
	(3,4,2,1,1,3,'','{\"typeId\":\"2\",\"authorId\":\"1\",\"title\":\"Test Entry\",\"slug\":\"gregs-entry\",\"postDate\":1544824500,\"expiryDate\":null,\"enabled\":true,\"newParentId\":\"\",\"fields\":{\"4\":[],\"3\":[],\"8\":{\"6\":{\"type\":\"1\",\"fields\":{\"sectionBlocks\":{\"7\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"text\":\"<p>Left side</p>\",\"width\":[\"3\"]}},\"8\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"text\":\"<p>Right side</p>\",\"width\":[\"3\"]}},\"9\":{\"type\":\"text\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"text\":\"<p>All of it!!!</p>\",\"width\":[\"2\"]}}}}}}}}','2018-12-15 00:09:22','2018-12-15 00:09:22','d88e592b-484f-4119-8e63-3a78afbc911a');

/*!40000 ALTER TABLE `craft_entryversions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldgroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldgroups`;

CREATE TABLE `craft_fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_fieldgroups` WRITE;
/*!40000 ALTER TABLE `craft_fieldgroups` DISABLE KEYS */;

INSERT INTO `craft_fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'Common','2018-12-11 18:44:42','2018-12-11 18:44:42','d6c6f6a3-32ed-45a1-897c-0094a54e0cb9'),
	(2,'Hero','2018-12-13 14:24:42','2018-12-13 14:24:50','4efd1e35-78bd-4a20-8f0d-406b413ddc73'),
	(3,'Product','2018-12-13 14:27:02','2018-12-13 22:03:14','9a1c358e-2009-45e0-af1e-65447822a4fc'),
	(5,'Callout','2018-12-13 17:15:56','2018-12-13 17:15:56','1c434abb-4a92-4509-a90e-2766fa1e5c76'),
	(6,'CTA','2018-12-13 17:45:38','2018-12-13 17:45:38','1ca9f70d-6999-43dc-8a02-10de8aeaa4cc'),
	(7,'Logo Wall','2018-12-13 21:44:25','2018-12-13 21:44:25','8ecb625e-bc2a-44ed-924b-feb9e7d5122b'),
	(8,'Related Product','2018-12-13 21:56:36','2018-12-13 21:56:36','769ee64b-4152-4821-aef6-715e986929b3'),
	(9,'Solution','2018-12-13 22:02:59','2018-12-13 22:03:20','fdbe269a-8aab-4b29-adb6-57cbc3fec11d');

/*!40000 ALTER TABLE `craft_fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayoutfields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayoutfields`;

CREATE TABLE `craft_fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `craft_fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `craft_fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `craft_fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `craft_fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayoutfields` DISABLE KEYS */;

INSERT INTO `craft_fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(126,4,52,10,1,1,'2018-12-13 21:46:18','2018-12-13 21:46:18','c8bb4cb4-5d8e-4877-81ee-70734a6d2d5c'),
	(127,4,52,11,1,2,'2018-12-13 21:46:18','2018-12-13 21:46:18','93cbbbc6-f5d1-47a1-86e9-73f97b393ec6'),
	(128,4,52,12,1,3,'2018-12-13 21:46:18','2018-12-13 21:46:18','f305dd76-3182-4368-b2d4-45fce153405d'),
	(129,4,52,13,1,4,'2018-12-13 21:46:18','2018-12-13 21:46:18','da0b1546-c912-4e14-a29c-af82f4c2ce81'),
	(130,4,52,14,1,5,'2018-12-13 21:46:18','2018-12-13 21:46:18','5bd70d71-4bc5-4010-845b-9664985a3f22'),
	(131,4,52,15,1,6,'2018-12-13 21:46:18','2018-12-13 21:46:18','9364ca88-8398-4c62-8c9e-a438634c89ba'),
	(132,7,53,25,1,1,'2018-12-13 21:46:29','2018-12-13 21:46:29','f9ffa611-7a03-4b06-bece-183963dfbb70'),
	(133,7,53,26,0,2,'2018-12-13 21:46:29','2018-12-13 21:46:29','56d32e38-acc1-404e-83c6-1f17a6bf830f'),
	(134,7,53,27,1,3,'2018-12-13 21:46:29','2018-12-13 21:46:29','b7be6fb6-eff4-42e2-ae68-1620dd18c8d5'),
	(135,7,53,28,1,4,'2018-12-13 21:46:29','2018-12-13 21:46:29','b3ced1d7-1a21-4d7d-87d2-5c0cc0d6fd0b'),
	(138,19,55,41,0,1,'2018-12-13 22:02:02','2018-12-13 22:02:02','4a107246-9c86-4f08-b47b-434095800411'),
	(139,19,55,40,0,2,'2018-12-13 22:02:02','2018-12-13 22:02:02','c1db67f1-fde6-43cd-92d6-34a9c7401f24'),
	(144,21,58,45,0,1,'2018-12-13 23:08:02','2018-12-13 23:08:02','4be40a93-5b9d-425a-a713-319697d7cacd'),
	(145,21,58,46,1,2,'2018-12-13 23:08:02','2018-12-13 23:08:02','76cff6ab-468d-4b0c-a60b-6fbf58896d06'),
	(146,21,58,47,1,3,'2018-12-13 23:08:02','2018-12-13 23:08:02','a674050a-45a9-4324-a0a2-0bf320a13642'),
	(147,22,59,52,1,1,'2018-12-13 23:15:33','2018-12-13 23:15:33','b2313f74-58a6-4eef-8953-251e60710ba0'),
	(148,22,59,53,1,2,'2018-12-13 23:15:33','2018-12-13 23:15:33','2fe46ea1-7927-4117-b358-339b3f5c9833'),
	(149,22,59,54,1,3,'2018-12-13 23:15:33','2018-12-13 23:15:33','6d644884-c0ba-482c-acd6-2ab952aa5182'),
	(150,23,60,56,1,1,'2018-12-13 23:15:33','2018-12-13 23:15:33','7ceac787-9396-49a6-b8ba-463207de12a0'),
	(151,23,60,57,1,2,'2018-12-13 23:15:33','2018-12-13 23:15:33','596cf022-34f9-41b6-ba91-7a3c4cd2605b'),
	(152,24,61,51,0,1,'2018-12-13 23:15:33','2018-12-13 23:15:33','cd21a68b-9001-4a6d-80b4-0c23893f93e8'),
	(153,24,61,55,0,2,'2018-12-13 23:15:33','2018-12-13 23:15:33','b86ffa85-4d21-427c-88e0-b972222acd7e'),
	(174,25,73,59,1,1,'2018-12-13 23:25:48','2018-12-13 23:25:48','2fb1261e-0a0a-4093-a5a2-1cac0bd00676'),
	(175,25,73,60,1,2,'2018-12-13 23:25:48','2018-12-13 23:25:48','aeb0246c-79dc-410a-99e6-c4f8aa3c129e'),
	(176,25,73,61,0,3,'2018-12-13 23:25:48','2018-12-13 23:25:48','a3ee6f76-d3c2-4f3e-bbac-24e2c0db5637'),
	(177,26,74,58,1,1,'2018-12-13 23:25:48','2018-12-13 23:25:48','0f68dcfb-5989-4923-a754-3b30adbf2ed5'),
	(178,27,75,63,1,1,'2018-12-13 23:25:48','2018-12-13 23:25:48','c3d405e1-937c-4242-951f-d0a879f2d7b9'),
	(179,27,75,65,0,2,'2018-12-13 23:25:48','2018-12-13 23:25:48','347fd526-efdc-4f00-adba-35b30626df4e'),
	(180,28,76,62,1,1,'2018-12-13 23:25:48','2018-12-13 23:25:48','ab8572a6-3ab8-408e-a2d6-19953f862039'),
	(181,9,77,2,0,1,'2018-12-13 23:26:53','2018-12-13 23:26:53','0e91054d-0c4d-4d7d-86ea-186fe7a65bb0'),
	(182,9,77,1,0,2,'2018-12-13 23:26:53','2018-12-13 23:26:53','0559c8f6-897d-4f58-a11c-3caec82a9e98'),
	(183,9,78,44,0,1,'2018-12-13 23:26:53','2018-12-13 23:26:53','712f4b19-2c2d-4aff-bf52-f6680141e3b3'),
	(184,9,79,48,0,1,'2018-12-13 23:26:53','2018-12-13 23:26:53','78aae804-a256-44dd-ba45-3d68d0c65015'),
	(185,9,79,49,0,2,'2018-12-13 23:26:53','2018-12-13 23:26:53','ec57e777-11ab-4af3-960f-cdd00ba7e9e6'),
	(186,9,79,50,0,3,'2018-12-13 23:26:53','2018-12-13 23:26:53','db101944-8c26-42d9-b5f3-262a3c35c0e9'),
	(187,9,80,8,0,1,'2018-12-13 23:26:53','2018-12-13 23:26:53','566a459f-8e42-41a3-97a8-25700af6da71'),
	(188,20,81,43,0,1,'2018-12-13 23:30:53','2018-12-13 23:30:53','06548163-8c8b-4343-b149-afca3f2b14d7'),
	(189,20,81,42,0,2,'2018-12-13 23:30:53','2018-12-13 23:30:53','37bfcb51-ea5f-45fe-a673-dafed3bf2a17'),
	(221,8,95,29,1,1,'2018-12-14 21:58:44','2018-12-14 21:58:44','85ce33b5-4905-4f1b-8cc9-1eb303dfdab7'),
	(222,3,96,16,1,1,'2018-12-14 21:58:44','2018-12-14 21:58:44','01e8c234-7b77-4157-b1eb-025549bdbd9a'),
	(223,5,97,17,1,1,'2018-12-14 21:58:45','2018-12-14 21:58:45','e8e93e2d-fb86-42ff-9a8e-2e7d3d397a0e'),
	(224,5,97,18,1,2,'2018-12-14 21:58:45','2018-12-14 21:58:45','6f9e9ea5-1038-4d66-9ffe-41c2901528d0'),
	(225,5,97,19,1,3,'2018-12-14 21:58:45','2018-12-14 21:58:45','26b0e010-fd88-459e-9541-566952b67496'),
	(226,5,97,20,1,4,'2018-12-14 21:58:45','2018-12-14 21:58:45','a4578a7e-c513-4597-af13-88a96564b055'),
	(227,5,97,21,0,5,'2018-12-14 21:58:45','2018-12-14 21:58:45','4b218a32-20dd-4883-891f-f9251be41340'),
	(228,5,97,22,0,6,'2018-12-14 21:58:45','2018-12-14 21:58:45','642fd2a3-e848-4e64-975c-c2a242263941'),
	(229,5,97,23,1,7,'2018-12-14 21:58:45','2018-12-14 21:58:45','36b5a8dc-50cb-4114-adb1-3501cb57e046'),
	(230,5,97,24,0,8,'2018-12-14 21:58:45','2018-12-14 21:58:45','216a5c5e-7aaa-40e7-9185-b8c0d5cc16ee'),
	(231,18,98,39,1,1,'2018-12-14 21:58:45','2018-12-14 21:58:45','d7e3c3b4-3e5d-4a8b-8862-e791b015a57d'),
	(232,29,99,66,1,1,'2018-12-14 21:58:45','2018-12-14 21:58:45','78432c9a-d74c-44b9-9892-ff2c48b2ea65'),
	(233,29,99,67,0,2,'2018-12-14 21:58:45','2018-12-14 21:58:45','76d3b123-bbeb-457c-8120-e752a9493115'),
	(234,2,100,9,0,1,'2018-12-14 21:58:45','2018-12-14 21:58:45','d0b6b92f-f286-40cd-aabc-17eee3e4c23a'),
	(235,1,101,5,0,1,'2018-12-14 21:59:19','2018-12-14 21:59:19','c9d7230b-f536-4294-989a-d32090bf940e'),
	(236,1,101,6,1,2,'2018-12-14 21:59:19','2018-12-14 21:59:19','dc6ad9b1-1b1f-4b0b-b466-4129fb85b256'),
	(237,1,101,7,1,3,'2018-12-14 21:59:19','2018-12-14 21:59:19','0a31e6be-5c3f-4112-85fa-5278d34007d5'),
	(238,6,102,2,0,1,'2018-12-14 21:59:33','2018-12-14 21:59:33','6acf6e4f-da2f-4c84-a7c5-d924dcb848bf'),
	(239,6,102,1,0,2,'2018-12-14 21:59:33','2018-12-14 21:59:33','a1a291dd-f83d-4347-88eb-c4d129cb6294'),
	(240,6,103,4,0,1,'2018-12-14 21:59:33','2018-12-14 21:59:33','a4532d0a-c4bd-4c66-b963-9bb0ddb16845'),
	(241,6,103,3,0,2,'2018-12-14 21:59:33','2018-12-14 21:59:33','9c08898d-6649-4b30-83dc-dbadf7f8c0a4'),
	(242,6,104,8,0,1,'2018-12-14 21:59:33','2018-12-14 21:59:33','10412d16-097f-4279-a2a8-2eb65fa9bff4');

/*!40000 ALTER TABLE `craft_fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayouts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayouts`;

CREATE TABLE `craft_fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_fieldlayouts` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouts` DISABLE KEYS */;

INSERT INTO `craft_fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'craft\\elements\\MatrixBlock','2018-12-13 14:35:49','2018-12-14 21:59:19','c4a00d5a-a576-48fd-81d5-d288c6c3206a'),
	(2,'verbb\\supertable\\elements\\SuperTableBlockElement','2018-12-13 17:12:09','2018-12-14 21:58:45','964173c8-1348-447e-a4bf-8d6991bb02f6'),
	(3,'craft\\elements\\MatrixBlock','2018-12-13 17:24:42','2018-12-14 21:58:44','ce385d85-af52-41d3-a3a0-3139ac940b4f'),
	(4,'craft\\elements\\Entry','2018-12-13 17:25:55','2018-12-13 21:46:18','a4293a30-f361-4b23-9de1-9c0aec6c956d'),
	(5,'craft\\elements\\MatrixBlock','2018-12-13 17:40:56','2018-12-14 21:58:45','d43926dd-df19-44c2-9a7d-9fbd38424c16'),
	(6,'craft\\elements\\Entry','2018-12-13 17:41:54','2018-12-14 21:59:33','00bfdae3-459e-4b50-ac68-8403fe3e1d0d'),
	(7,'craft\\elements\\Entry','2018-12-13 17:47:38','2018-12-13 21:46:29','c32515fd-3b90-4c12-b619-b6fb6949d270'),
	(8,'craft\\elements\\MatrixBlock','2018-12-13 17:52:11','2018-12-14 21:58:44','2596a962-704c-48aa-96fd-f3cc73e22881'),
	(9,'craft\\elements\\Entry','2018-12-13 17:53:19','2018-12-13 23:26:53','6e1699fe-70f2-436a-9407-a2715c75e4e3'),
	(16,'Spoon_BlockType','2018-12-13 20:42:44','2018-12-13 20:42:44','5eed54ad-bfa7-47bf-b48c-e2b22622e843'),
	(17,'craft\\elements\\Category','2018-12-13 21:37:35','2018-12-13 21:37:35','ab0fc408-82a6-4e41-92a0-94101a52e802'),
	(18,'craft\\elements\\MatrixBlock','2018-12-13 21:40:00','2018-12-14 21:58:45','a3ecb888-2422-4dff-b6b0-f60dd0433e47'),
	(19,'craft\\elements\\Entry','2018-12-13 21:40:22','2018-12-13 22:02:02','6f90bc60-bb1a-45e7-9824-561f84160dff'),
	(20,'craft\\elements\\Entry','2018-12-13 21:43:32','2018-12-13 23:30:53','f4d84c19-0831-46d5-af15-6d7cf7a79b99'),
	(21,'craft\\elements\\MatrixBlock','2018-12-13 23:05:58','2018-12-13 23:08:02','a4c0dac5-e912-4155-9c39-cf28ccdd64ab'),
	(22,'craft\\elements\\MatrixBlock','2018-12-13 23:15:33','2018-12-13 23:15:33','55d74458-fc06-44c6-a7e2-e7640625a26b'),
	(23,'craft\\elements\\MatrixBlock','2018-12-13 23:15:33','2018-12-13 23:15:33','851763dd-b2f4-4389-8c92-ed0250850e1a'),
	(24,'verbb\\supertable\\elements\\SuperTableBlockElement','2018-12-13 23:15:33','2018-12-13 23:15:33','c7684c34-7a71-4984-913b-11dd0c13bb41'),
	(25,'verbb\\supertable\\elements\\SuperTableBlockElement','2018-12-13 23:24:22','2018-12-13 23:25:48','c86cb7ee-b22e-4ff4-bd95-7f76b01eee14'),
	(26,'craft\\elements\\MatrixBlock','2018-12-13 23:24:22','2018-12-13 23:25:48','adc508b5-0d4d-490a-a7c2-59f69efcc51a'),
	(27,'verbb\\supertable\\elements\\SuperTableBlockElement','2018-12-13 23:24:23','2018-12-13 23:25:48','af7b0438-67f8-4c86-8e12-9678d0960f1e'),
	(28,'craft\\elements\\MatrixBlock','2018-12-13 23:24:23','2018-12-13 23:25:48','5807c508-4968-423f-afbc-59ed21ef5bae'),
	(29,'craft\\elements\\MatrixBlock','2018-12-14 21:53:40','2018-12-14 21:58:45','6151cca9-4df4-4f5f-9840-8f13fa9db77e');

/*!40000 ALTER TABLE `craft_fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayouttabs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayouttabs`;

CREATE TABLE `craft_fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `craft_fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouttabs` DISABLE KEYS */;

INSERT INTO `craft_fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(36,16,'Fields',1,'2018-12-13 20:42:44','2018-12-13 20:42:44','6b8b4747-692d-4303-8441-828a66ee749d'),
	(52,4,'Main',1,'2018-12-13 21:46:18','2018-12-13 21:46:18','e6677e18-52cd-46e7-850a-28990035dfb5'),
	(53,7,'Main',1,'2018-12-13 21:46:29','2018-12-13 21:46:29','ba40a7d2-b46e-4fe9-b835-41f7233f060c'),
	(55,19,'Main',1,'2018-12-13 22:02:02','2018-12-13 22:02:02','33e179be-be24-4105-bbb7-e63d50f8d388'),
	(58,21,'Content',1,'2018-12-13 23:08:02','2018-12-13 23:08:02','72b0bf47-4111-4d77-8a94-9e84c1d344fd'),
	(59,22,'Content',1,'2018-12-13 23:15:33','2018-12-13 23:15:33','53830b23-aa9c-44a8-8352-8227079c5bac'),
	(60,23,'Content',1,'2018-12-13 23:15:33','2018-12-13 23:15:33','0e86e52f-d990-4adf-a347-1d3373548543'),
	(61,24,'Content',1,'2018-12-13 23:15:33','2018-12-13 23:15:33','602c4e60-f2d3-4169-a94d-f4ff6dcde8b6'),
	(73,25,'Content',1,'2018-12-13 23:25:48','2018-12-13 23:25:48','231acbe2-41bc-4594-a1fe-707482298ca0'),
	(74,26,'Content',1,'2018-12-13 23:25:48','2018-12-13 23:25:48','f495445b-3073-4ff8-a397-e3a7c88fa8f9'),
	(75,27,'Content',1,'2018-12-13 23:25:48','2018-12-13 23:25:48','0491b980-f252-482e-84b1-4b51184f3522'),
	(76,28,'Content',1,'2018-12-13 23:25:48','2018-12-13 23:25:48','2a53006c-8ce9-4a98-af4a-1e0bc9f29f51'),
	(77,9,'Hero',1,'2018-12-13 23:26:53','2018-12-13 23:26:53','65faab98-96c3-4a2f-81ab-28f2e7ccc8d3'),
	(78,9,'Key Areas',2,'2018-12-13 23:26:53','2018-12-13 23:26:53','1307081b-63ab-498a-894c-da17f7444118'),
	(79,9,'Product Introduction',3,'2018-12-13 23:26:53','2018-12-13 23:26:53','42aeb410-c76a-46da-a878-ef7d37b2b339'),
	(80,9,'More Content',4,'2018-12-13 23:26:53','2018-12-13 23:26:53','0dcbded2-5e31-4a01-b6c7-c8d4a134b982'),
	(81,20,'Main',1,'2018-12-13 23:30:53','2018-12-13 23:30:53','33cb63fd-6701-475f-a2fb-81977f991bbd'),
	(95,8,'Content',1,'2018-12-14 21:58:44','2018-12-14 21:58:44','c86ac974-c152-47e2-9fe9-28eaa2194aa4'),
	(96,3,'Content',1,'2018-12-14 21:58:44','2018-12-14 21:58:44','3f6611f2-d981-4531-b8d8-82e966e0a12a'),
	(97,5,'Content',1,'2018-12-14 21:58:45','2018-12-14 21:58:45','df6b64d5-8029-4e4a-8757-07d92b480c2e'),
	(98,18,'Content',1,'2018-12-14 21:58:45','2018-12-14 21:58:45','3f48b667-07dd-46c4-8212-0f4dd7444a4a'),
	(99,29,'Content',1,'2018-12-14 21:58:45','2018-12-14 21:58:45','a88ba331-eb27-4362-b78c-2f50b61fc221'),
	(100,2,'Content',1,'2018-12-14 21:58:45','2018-12-14 21:58:45','1a7811ce-321a-47cb-a5db-d1135f5ef79d'),
	(101,1,'Content',1,'2018-12-14 21:59:19','2018-12-14 21:59:19','34b44036-80ae-4f89-ad51-da52397f8643'),
	(102,6,'Hero',1,'2018-12-14 21:59:33','2018-12-14 21:59:33','70cb13f4-1c4f-4c8d-9fb1-a40099dd85b9'),
	(103,6,'How It Works',2,'2018-12-14 21:59:33','2018-12-14 21:59:33','447c6f55-d56e-4c90-99d6-c8048a9de9f3'),
	(104,6,'More Content',3,'2018-12-14 21:59:33','2018-12-14 21:59:33','413046b9-bb63-4fc2-8864-e2d8373e7cb1');

/*!40000 ALTER TABLE `craft_fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fields`;

CREATE TABLE `craft_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `craft_fields_groupId_idx` (`groupId`),
  KEY `craft_fields_context_idx` (`context`),
  CONSTRAINT `craft_fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_fields` WRITE;
/*!40000 ALTER TABLE `craft_fields` DISABLE KEYS */;

INSERT INTO `craft_fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,2,'Hero: Title','heroTitle','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 14:25:35','2018-12-13 14:30:46','597741ac-a8d9-460d-ab73-c4c605ed9a2b'),
	(2,2,'Hero: Description','heroDescription','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 14:26:25','2018-12-13 14:48:49','5da8930b-7201-4134-aa1d-2e7d8c621498'),
	(3,3,'How It Works: Master Image','howItWorksMasterImage','global','This is the base screenshot used across all blocks below','site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":null,\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":null,\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"Add an image\",\"localizeRelations\":false}','2018-12-13 14:30:26','2018-12-13 14:30:26','b8f9bbb3-0569-4947-b89b-8bfb6087ada3'),
	(4,3,'How It Works: Blocks','howItWorksBlocks','global','','site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"\",\"maxBlocks\":\"5\",\"contentTable\":\"{{%matrixcontent_howitworksblocks}}\",\"localizeBlocks\":false}','2018-12-13 14:31:44','2018-12-14 21:59:19','5e997974-c7e9-4971-801d-8a016a57ccd7'),
	(5,NULL,'Heading','heading','matrixBlockType:1','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 14:35:49','2018-12-14 21:59:19','e776ab49-6ab0-4ee9-bfef-cda8879b1794'),
	(6,NULL,'Description','description','matrixBlockType:1','','none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"Links.json\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}','2018-12-13 14:35:49','2018-12-14 21:59:19','f744f4ca-2b8b-45e8-a9ce-22e61daf1a6e'),
	(7,NULL,'Magnified Screenshot','magnifiedScreenshot','matrixBlockType:1','This is placed on top of the master screenshot specified earlier','site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":null,\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":null,\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"Add an image\",\"localizeRelations\":false}','2018-12-13 14:48:30','2018-12-14 21:59:19','fe4c4842-e68c-448d-967a-575f6c75b37d'),
	(8,1,'Page Sections','pageSections','global','Flexible page sections with nested blocks that can be used to add content.','site',NULL,'verbb\\supertable\\fields\\SuperTableField','{\"minRows\":\"\",\"maxRows\":\"\",\"localizeBlocks\":false,\"staticField\":\"\",\"columns\":{\"9\":{\"width\":\"\"}},\"contentTable\":null,\"fieldLayout\":\"row\",\"selectionLabel\":\"\"}','2018-12-13 16:35:44','2018-12-14 21:58:44','d16fedf6-6cd2-468a-8677-ee587e68315b'),
	(9,NULL,'Section Blocks','sectionBlocks','superTableBlockType:1','','site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"contentTable\":\"{{%matrixcontent_sectionblocks}}\",\"localizeBlocks\":false}','2018-12-13 17:12:09','2018-12-14 21:58:44','3d5cf55a-e8ee-4ee7-986d-3cf0a625f14b'),
	(10,5,'Callout: Image','calloutImage','global','','site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":null,\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":null,\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"Add an image\",\"localizeRelations\":false}','2018-12-13 17:16:25','2018-12-13 17:16:25','d42f9255-8bb7-41b5-93cc-4ef9520ebc95'),
	(11,5,'Callout: Image Alignment','calloutImageAlignment','global','','none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Left\",\"value\":\"left\",\"default\":\"1\"},{\"label\":\"Right\",\"value\":\"right\",\"default\":\"\"}]}','2018-12-13 17:17:34','2018-12-13 17:17:34','207956cb-c12d-4117-bdcd-c82adf2bcea9'),
	(12,5,'Callout: Headline','calloutTitle','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:18:24','2018-12-13 17:18:24','1d7d04c9-3c3e-4c1d-972e-44d02f823e1b'),
	(13,5,'Callout: Description','calloutDescription','global','','none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"BoldItalicList.json\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}','2018-12-13 17:21:58','2018-12-13 17:21:58','4c39b9fb-dedb-4850-b8e0-db5658b9021c'),
	(14,5,'Callout: CTA Text','calloutCtaText','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:22:24','2018-12-13 17:22:24','9a011237-02ff-4401-9e77-20be67df2cb6'),
	(15,5,'Callout: CTA URL','calloutCtaUrl','global','','none',NULL,'craft\\fields\\Url','{\"placeholder\":\"\"}','2018-12-13 17:22:42','2018-12-13 17:22:42','c11fbc07-32bb-478a-bb0d-b2e9baa7ddf8'),
	(16,NULL,'Callout','calloutEntry','matrixBlockType:2','','site',NULL,'craft\\fields\\Entries','{\"sources\":[\"section:1\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"Add a callout\",\"localizeRelations\":false}','2018-12-13 17:24:42','2018-12-14 21:58:44','0405c574-6150-42e6-b4ed-7e758afec196'),
	(17,NULL,'Featured Resource','featuredResource','matrixBlockType:3','','site',NULL,'craft\\fields\\Entries','{\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"Add a resource\",\"localizeRelations\":false}','2018-12-13 17:40:56','2018-12-14 21:58:44','382fc525-5a57-4ed4-9abe-13d421f1878b'),
	(18,NULL,'Featured Quote: Title','featuredQuoteTitle','matrixBlockType:3','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:40:56','2018-12-14 21:58:45','bf44adde-dc2f-4913-ac88-8363277d9e5f'),
	(19,NULL,'Featured Quote: Text','featuredQuoteText','matrixBlockType:3','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:40:56','2018-12-14 21:58:45','df49063c-cd46-411b-abed-2d4ac44d1d73'),
	(20,NULL,'Featured Quote: Attribution - Name','featuredQuoteAttributionName','matrixBlockType:3','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:40:56','2018-12-14 21:58:45','614c889c-cdec-413b-93cd-cf45a2f4c5a5'),
	(21,NULL,'Featured Quote: Attribution - Title','featuredQuoteAttributionTitle','matrixBlockType:3','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:40:56','2018-12-14 21:58:45','7c38a3f2-a12d-4283-a807-d71083f39d35'),
	(22,NULL,'Featured Quote: Attribution - Company','featuredQuoteAttributionCompany','matrixBlockType:3','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:40:56','2018-12-14 21:58:45','349c9fff-23b9-49f4-b115-cb9792c55308'),
	(23,NULL,'Featured Quote: Use Quotes?','featuredQuoteUseQuotes','matrixBlockType:3','Should quotation marks automatically appear around your text?','none',NULL,'craft\\fields\\Lightswitch','{\"default\":\"1\"}','2018-12-13 17:40:56','2018-12-14 21:58:45','fcf2e3db-dce0-46f1-a39e-bdfb7a5caff5'),
	(24,NULL,'Secondary Resources','secondaryResources','matrixBlockType:3','These resources appear as links beneath the featured resource','site',NULL,'craft\\fields\\Entries','{\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"3\",\"selectionLabel\":\"Add a resource\",\"localizeRelations\":false}','2018-12-13 17:40:56','2018-12-14 21:58:45','a1a42735-89c2-484e-b278-c0af8c74bb06'),
	(25,6,'CTA: Headline','ctaTitle','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:45:58','2018-12-13 17:45:58','f4a9163d-dc2d-4796-974d-d537e8f7aa01'),
	(26,6,'CTA: Subheading','ctaSubtitle','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:46:35','2018-12-13 17:46:35','9d7b84cd-85b7-4e04-ad50-b8fba8910568'),
	(27,6,'CTA: Link Text','ctaLinkText','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 17:46:59','2018-12-13 17:46:59','71a8ab37-7c13-47ca-840a-4c93bd1a8389'),
	(28,6,'CTA: Link URL','ctaLinkUrl','global','','none',NULL,'craft\\fields\\Url','{\"placeholder\":\"\"}','2018-12-13 17:47:11','2018-12-13 17:47:11','78e9c4ed-53ed-45d1-bbc9-74b340b42c89'),
	(29,NULL,'CTA Entry/Entries','ctaEntries','matrixBlockType:4','','site',NULL,'craft\\fields\\Entries','{\"sources\":[\"section:3\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"2\",\"selectionLabel\":\"Add a CTA entry\",\"localizeRelations\":false}','2018-12-13 17:52:11','2018-12-14 21:58:44','24745052-2294-4505-8608-0fcb27d093b7'),
	(39,NULL,'Logos','logoEntries','matrixBlockType:8','','site',NULL,'craft\\fields\\Entries','{\"sources\":[\"section:5\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"8\",\"selectionLabel\":\"Add a logo\",\"localizeRelations\":false}','2018-12-13 21:40:00','2018-12-14 21:58:45','956d71a2-816c-4ad8-9857-e013f61ca07e'),
	(40,7,'Logo: Name','logoName','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 21:44:44','2018-12-13 21:44:44','61ac827e-ba86-40f6-b6a1-a890c52dd78a'),
	(41,7,'Logo: Image','logoImage','global','','site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":null,\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":null,\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"Add an image\",\"localizeRelations\":false}','2018-12-13 21:45:44','2018-12-13 21:45:44','76d8ba9f-70ac-4ddd-994d-3bf052d08a82'),
	(42,8,'Related Product: Product','relatedProductEntry','global','','site',NULL,'craft\\fields\\Entries','{\"sources\":[\"section:6\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"Add a product\",\"localizeRelations\":false}','2018-12-13 21:57:21','2018-12-13 21:57:21','bd29aa1a-0cde-4cdf-b72f-94ab404648b7'),
	(43,8,'Related Product: Description','relatedProductDescription','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 21:59:13','2018-12-13 21:59:13','6fe91928-a859-46ef-ba52-03759c5f06de'),
	(44,9,'Key Areas','keyAreas','global','','site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"1\",\"maxBlocks\":\"5\",\"contentTable\":\"{{%matrixcontent_keyareas}}\",\"localizeBlocks\":false}','2018-12-13 23:05:58','2018-12-13 23:08:01','dc3d8c33-6dd1-45eb-ae3e-4790c64ca06e'),
	(45,NULL,'Headline','keyAreaTitle','matrixBlockType:9','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 23:05:58','2018-12-13 23:08:02','f88c6d44-0a4b-4fe5-9607-567d7bff72f6'),
	(46,NULL,'Description','description','matrixBlockType:9','','none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"Links.json\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}','2018-12-13 23:07:49','2018-12-13 23:08:02','4021ec60-df0b-4bd1-ba13-8dec803b6a99'),
	(47,NULL,'Image','image','matrixBlockType:9','','site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":null,\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":null,\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"allowedKinds\":null,\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"Add an image\",\"localizeRelations\":false}','2018-12-13 23:07:49','2018-12-13 23:08:02','67949111-8743-4536-a337-bc056a695a00'),
	(48,9,'Product Introduction: Headline','productIntroductionTitle','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 23:10:09','2018-12-13 23:10:09','c9bbff8a-3eca-4991-818f-4bb71dd66cb2'),
	(49,9,'Production Introduction: Description','productionIntroductionDescription','global','','none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"BoldItalic.json\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}','2018-12-13 23:10:32','2018-12-13 23:10:32','402fdbf5-fe02-4713-9403-d484e1aedfd4'),
	(50,9,'Product Introduction: Products','productIntroductionProducts','global','','site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"1\",\"maxBlocks\":\"1\",\"contentTable\":\"{{%matrixcontent_productintroductionproducts}}\",\"localizeBlocks\":false}','2018-12-13 23:15:32','2018-12-13 23:25:47','c5e36576-5ad4-48ec-aa50-1973f4f6c267'),
	(51,NULL,'Accordion','accordion','superTableBlockType:3','','site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"\",\"maxBlocks\":\"6\",\"contentTable\":\"{{%matrixcontent_accordion}}\",\"localizeBlocks\":false}','2018-12-13 23:15:32','2018-12-13 23:15:32','a28b38fb-8488-488c-b738-d4c3d6bc8d39'),
	(52,NULL,'Related Product','relatedProduct','matrixBlockType:10','','site',NULL,'craft\\fields\\Entries','{\"sources\":[\"section:2\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"Relate a product\",\"localizeRelations\":false}','2018-12-13 23:15:33','2018-12-13 23:15:33','5cc7bef1-ac09-482c-aa03-ee851571bfb1'),
	(53,NULL,'Headline','itemTitle','matrixBlockType:10','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 23:15:33','2018-12-13 23:15:33','3fbe60b6-fac4-4ea5-8687-d6adf4ca9806'),
	(54,NULL,'Description','description','matrixBlockType:10','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 23:15:33','2018-12-13 23:15:33','e8c88599-3fb4-419d-b76b-2c8a0fca3e5a'),
	(55,NULL,'Grid','grid','superTableBlockType:3','','site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"\",\"maxBlocks\":\"5\",\"contentTable\":\"{{%matrixcontent_grid}}\",\"localizeBlocks\":false}','2018-12-13 23:15:33','2018-12-13 23:15:33','1eb980f1-37f0-4d2f-b4f3-2687731719cc'),
	(56,NULL,'Related Product','relatedProduct','matrixBlockType:11','','site',NULL,'craft\\fields\\Entries','{\"sources\":[\"section:2\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"Relate a product\",\"localizeRelations\":false}','2018-12-13 23:15:33','2018-12-13 23:15:33','d0af562c-d2c4-4bfc-8abb-f25ad12edaaa'),
	(57,NULL,'Description','description','matrixBlockType:11','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 23:15:33','2018-12-13 23:15:33','0a96bbcd-0861-4232-b961-9c09b6824e56'),
	(58,NULL,'Accordion Item','items','matrixBlockType:12','','site',NULL,'verbb\\supertable\\fields\\SuperTableField','{\"minRows\":\"\",\"maxRows\":\"6\",\"localizeBlocks\":false,\"staticField\":\"\",\"columns\":{\"59\":{\"width\":\"\"},\"60\":{\"width\":\"\"},\"61\":{\"width\":\"\"}},\"contentTable\":null,\"fieldLayout\":\"row\",\"selectionLabel\":\"Add an accordion item\"}','2018-12-13 23:24:22','2018-12-13 23:25:47','7ea4f87b-2e07-4662-befa-452aacd70849'),
	(59,NULL,'Related Product','relatedProduct','superTableBlockType:4','','site',NULL,'craft\\fields\\Entries','{\"sources\":[\"section:2\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"Relate a product\",\"localizeRelations\":false}','2018-12-13 23:24:22','2018-12-13 23:25:47','d9042b82-da25-44cb-a24f-26713153b6a4'),
	(60,NULL,'Headline','heading','superTableBlockType:4','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 23:24:22','2018-12-13 23:25:47','4e5cf774-91e8-4d3b-b399-d70ea144087f'),
	(61,NULL,'Description','description','superTableBlockType:4','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 23:24:22','2018-12-13 23:25:48','d09c3fe5-33a8-4910-a4fa-293c530e14fc'),
	(62,NULL,'Grid Items','items','matrixBlockType:13','','site',NULL,'verbb\\supertable\\fields\\SuperTableField','{\"minRows\":\"\",\"maxRows\":\"5\",\"localizeBlocks\":false,\"staticField\":\"\",\"columns\":{\"63\":{\"width\":\"\"}},\"contentTable\":null,\"fieldLayout\":\"row\",\"selectionLabel\":\"Add a grid item\"}','2018-12-13 23:24:22','2018-12-13 23:25:48','dac76e30-bc43-4023-8a04-1343c11a9d41'),
	(63,NULL,'Related Product','relatedProduct','superTableBlockType:5','','site',NULL,'craft\\fields\\Entries','{\"sources\":[\"section:2\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"Relate a product\",\"localizeRelations\":false}','2018-12-13 23:24:23','2018-12-13 23:25:48','39634564-1ea6-4019-a548-e1ffdb0fedb1'),
	(65,NULL,'Description','description','superTableBlockType:5','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2018-12-13 23:25:48','2018-12-13 23:25:48','45079b86-56fc-45c3-94ef-8ed08521a149'),
	(66,NULL,'Text','text','matrixBlockType:14','','none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}','2018-12-14 21:53:40','2018-12-14 21:58:45','b27b61ae-b2d4-477b-a040-f405cff37dff'),
	(67,NULL,'Width','width','matrixBlockType:14','','site',NULL,'craft\\fields\\Categories','{\"branchLimit\":\"1\",\"sources\":\"*\",\"source\":\"group:1\",\"targetSiteId\":null,\"viewMode\":null,\"limit\":null,\"selectionLabel\":\"Select width\",\"localizeRelations\":false}','2018-12-14 21:53:40','2018-12-14 21:58:45','0f338273-28d2-4947-9ab8-44470fa94734');

/*!40000 ALTER TABLE `craft_fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_globalsets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_globalsets`;

CREATE TABLE `craft_globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_globalsets_name_unq_idx` (`name`),
  UNIQUE KEY `craft_globalsets_handle_unq_idx` (`handle`),
  KEY `craft_globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_info`;

CREATE TABLE `craft_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `edition` tinyint(3) unsigned NOT NULL,
  `timezone` varchar(30) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_info` WRITE;
/*!40000 ALTER TABLE `craft_info` DISABLE KEYS */;

INSERT INTO `craft_info` (`id`, `version`, `schemaVersion`, `edition`, `timezone`, `name`, `on`, `maintenance`, `fieldVersion`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'3.0.35','3.0.94',0,'America/Los_Angeles','FiscalNote',1,0,'hz0mtE1BsyyT','2018-12-11 18:44:42','2018-12-14 21:59:19','45793d7e-4e7b-4fa4-bb04-836c6da058ee');

/*!40000 ALTER TABLE `craft_info` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixblocks`;

CREATE TABLE `craft_matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_matrixblocks_ownerId_idx` (`ownerId`),
  KEY `craft_matrixblocks_fieldId_idx` (`fieldId`),
  KEY `craft_matrixblocks_typeId_idx` (`typeId`),
  KEY `craft_matrixblocks_sortOrder_idx` (`sortOrder`),
  KEY `craft_matrixblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `craft_matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_matrixblocks` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocks` DISABLE KEYS */;

INSERT INTO `craft_matrixblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(7,6,NULL,9,14,1,'2018-12-14 21:59:38','2018-12-15 00:09:32','3d661fe1-355b-42d1-9dba-9d3db3897a20'),
	(8,6,NULL,9,14,2,'2018-12-14 21:59:38','2018-12-15 00:09:32','0b95e096-5682-4e4a-88f0-10add2792f92'),
	(9,6,NULL,9,14,3,'2018-12-14 21:59:38','2018-12-15 00:09:32','3bdbd239-1a3e-4fc1-a60c-67ca2a3d70c2');

/*!40000 ALTER TABLE `craft_matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixblocktypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixblocktypes`;

CREATE TABLE `craft_matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `craft_matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `craft_matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `craft_matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocktypes` DISABLE KEYS */;

INSERT INTO `craft_matrixblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,4,1,'Feature','feature',1,'2018-12-13 14:35:49','2018-12-14 21:59:19','4c3db109-8973-43d5-abee-d4c1a396d907'),
	(2,9,3,'Callout','callout',2,'2018-12-13 17:24:42','2018-12-14 21:58:44','abb2111f-4f1e-4e48-9426-07bed77e25a0'),
	(3,9,5,'Related Resources','relatedResources',3,'2018-12-13 17:40:56','2018-12-14 21:58:45','70f01567-6ae2-4dc3-942c-7b807ba25634'),
	(4,9,8,'CTA','cta',1,'2018-12-13 17:52:11','2018-12-14 21:58:44','1e069001-4e49-4d91-b3ba-b60dbfee6f8e'),
	(8,9,18,'Logo Wall','logoWall',4,'2018-12-13 21:40:00','2018-12-14 21:58:45','52a88962-e462-42f9-9f18-55ba83f3ee06'),
	(9,44,21,'Key Area','keyArea',1,'2018-12-13 23:05:58','2018-12-13 23:08:02','42aa5b79-4217-4587-aa0b-a7483c53fee4'),
	(10,51,22,'Accordion Item','item',1,'2018-12-13 23:15:33','2018-12-13 23:15:33','6bb39938-802e-4788-a7b3-83f7c0099ce7'),
	(11,55,23,'Grid Item','item',1,'2018-12-13 23:15:33','2018-12-13 23:15:33','8299b00a-ca5e-4397-b518-7398b1203adc'),
	(12,50,26,'Accordion','accordion',1,'2018-12-13 23:24:22','2018-12-13 23:25:48','042b751c-5d67-4fe3-99d3-1fe35d1e8a03'),
	(13,50,28,'Grid','grid',2,'2018-12-13 23:24:22','2018-12-13 23:25:48','1d4d2029-dd15-42c9-97f0-fed55cb11f3c'),
	(14,9,29,'Text','text',5,'2018-12-14 21:53:40','2018-12-14 21:58:45','b9cf8085-d71d-4771-b41a-06b792ac8f01');

/*!40000 ALTER TABLE `craft_matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixcontent_accordion
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixcontent_accordion`;

CREATE TABLE `craft_matrixcontent_accordion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_item_itemTitle` text,
  `field_item_description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixcontent_accordion_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_matrixcontent_accordion_siteId_fk` (`siteId`),
  CONSTRAINT `craft_matrixcontent_accordion_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_accordion_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_matrixcontent_grid
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixcontent_grid`;

CREATE TABLE `craft_matrixcontent_grid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_item_description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixcontent_grid_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_matrixcontent_grid_siteId_fk` (`siteId`),
  CONSTRAINT `craft_matrixcontent_grid_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_grid_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_matrixcontent_howitworksblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixcontent_howitworksblocks`;

CREATE TABLE `craft_matrixcontent_howitworksblocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_feature_heading` text,
  `field_feature_description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixcontent_howitworksblocks_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_matrixcontent_howitworksblocks_siteId_fk` (`siteId`),
  CONSTRAINT `craft_matrixcontent_howitworksblocks_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_howitworksblocks_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_matrixcontent_keyareas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixcontent_keyareas`;

CREATE TABLE `craft_matrixcontent_keyareas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_keyArea_keyAreaTitle` text,
  `field_keyArea_description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixcontent_keyareas_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_matrixcontent_keyareas_siteId_fk` (`siteId`),
  CONSTRAINT `craft_matrixcontent_keyareas_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_keyareas_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_matrixcontent_productintroductionproducts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixcontent_productintroductionproducts`;

CREATE TABLE `craft_matrixcontent_productintroductionproducts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craf_matrixconte_productintroductionprodu_elementI_siteI_unq_idx` (`elementId`,`siteId`),
  KEY `craft_matrixcontent_productintroductionproducts_siteId_fk` (`siteId`),
  CONSTRAINT `craft_matrixcontent_productintroductionproducts_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_productintroductionproducts_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_matrixcontent_sectionblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixcontent_sectionblocks`;

CREATE TABLE `craft_matrixcontent_sectionblocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_relatedResources_featuredQuoteTitle` text,
  `field_relatedResources_featuredQuoteText` text,
  `field_relatedResources_featuredQuoteAttributionName` text,
  `field_relatedResources_featuredQuoteAttributionTitle` text,
  `field_relatedResources_featuredQuoteAttributionCompany` text,
  `field_relatedResources_featuredQuoteUseQuotes` tinyint(1) DEFAULT NULL,
  `field_text_text` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixcontent_sectionblocks_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_matrixcontent_sectionblocks_siteId_fk` (`siteId`),
  CONSTRAINT `craft_matrixcontent_sectionblocks_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_sectionblocks_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_matrixcontent_sectionblocks` WRITE;
/*!40000 ALTER TABLE `craft_matrixcontent_sectionblocks` DISABLE KEYS */;

INSERT INTO `craft_matrixcontent_sectionblocks` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`, `field_relatedResources_featuredQuoteTitle`, `field_relatedResources_featuredQuoteText`, `field_relatedResources_featuredQuoteAttributionName`, `field_relatedResources_featuredQuoteAttributionTitle`, `field_relatedResources_featuredQuoteAttributionCompany`, `field_relatedResources_featuredQuoteUseQuotes`, `field_text_text`)
VALUES
	(1,7,1,'2018-12-14 21:59:38','2018-12-15 00:09:32','6cab2a25-88cf-4e91-b89d-3073b44716ca',NULL,NULL,NULL,NULL,NULL,NULL,'<p>Left side</p>'),
	(2,8,1,'2018-12-14 21:59:38','2018-12-15 00:09:32','9b350a9d-bd20-455d-96ab-92eac4ebd13c',NULL,NULL,NULL,NULL,NULL,NULL,'<p>Right side</p>'),
	(3,9,1,'2018-12-14 21:59:38','2018-12-15 00:09:32','25d3b950-7e1c-4fe8-93f9-2a2ad9ac3f00',NULL,NULL,NULL,NULL,NULL,NULL,'<p>All of it!!!</p>');

/*!40000 ALTER TABLE `craft_matrixcontent_sectionblocks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_migrations`;

CREATE TABLE `craft_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `type` enum('app','plugin','content') NOT NULL DEFAULT 'app',
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_migrations_pluginId_idx` (`pluginId`),
  KEY `craft_migrations_type_pluginId_idx` (`type`,`pluginId`),
  CONSTRAINT `craft_migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `craft_plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_migrations` WRITE;
/*!40000 ALTER TABLE `craft_migrations` DISABLE KEYS */;

INSERT INTO `craft_migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,'app','Install','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','4eff4bb9-7cfa-407a-b0ee-08bef464d76b'),
	(2,NULL,'app','m150403_183908_migrations_table_changes','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','ce90b6bc-6625-4bbb-9ba4-69fc9c357bb8'),
	(3,NULL,'app','m150403_184247_plugins_table_changes','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','5a5b01f2-d5fb-4de1-8393-8b8e5a2e89f0'),
	(4,NULL,'app','m150403_184533_field_version','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','007dbc75-3c3b-4019-a9a7-811f9bf4a7ef'),
	(5,NULL,'app','m150403_184729_type_columns','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','1935e2f1-aee8-479f-956c-afd9db2bba59'),
	(6,NULL,'app','m150403_185142_volumes','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','a0c26f36-41c4-4f91-96f8-11b0739780f2'),
	(7,NULL,'app','m150428_231346_userpreferences','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','7422ec1d-a388-4299-99f9-052d6963a6f9'),
	(8,NULL,'app','m150519_150900_fieldversion_conversion','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','f2380321-e8c9-45dc-ae55-b3c8aef3bc9a'),
	(9,NULL,'app','m150617_213829_update_email_settings','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','82e9d195-c714-463a-8bfd-967334c5112e'),
	(10,NULL,'app','m150721_124739_templatecachequeries','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','21561f57-53c9-48b7-bd6d-bdbd313651cf'),
	(11,NULL,'app','m150724_140822_adjust_quality_settings','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','874306c6-3781-4b5c-aa77-e86fa8c936e2'),
	(12,NULL,'app','m150815_133521_last_login_attempt_ip','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','92196bf9-bdcf-4af7-ba08-635c934f45a3'),
	(13,NULL,'app','m151002_095935_volume_cache_settings','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','c3fef0f1-9e28-4b7d-a69f-3748fc4c9b38'),
	(14,NULL,'app','m151005_142750_volume_s3_storage_settings','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','fa8a6742-2f4e-4a15-b05a-3ad4a07f2183'),
	(15,NULL,'app','m151016_133600_delete_asset_thumbnails','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','63c1558d-b394-4ec2-a6ff-6986a645aeb9'),
	(16,NULL,'app','m151209_000000_move_logo','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','88ea048d-722e-4104-b7c9-0d69f21c5fdf'),
	(17,NULL,'app','m151211_000000_rename_fileId_to_assetId','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','347bdfdf-baea-467e-bc02-f2537f69536d'),
	(18,NULL,'app','m151215_000000_rename_asset_permissions','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','f97c62ca-d8d4-4e81-8572-375a472d8ff3'),
	(19,NULL,'app','m160707_000001_rename_richtext_assetsource_setting','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','3fc49716-6387-4762-aa7b-a10016ba1ceb'),
	(20,NULL,'app','m160708_185142_volume_hasUrls_setting','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','82ff2f41-5ee0-4199-83e1-a2fcaccd0b0e'),
	(21,NULL,'app','m160714_000000_increase_max_asset_filesize','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','87428ac0-06ca-48cd-a7f7-4cc213f89d9f'),
	(22,NULL,'app','m160727_194637_column_cleanup','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','a5eee0e0-6635-4e0f-97be-eb1f462a87fb'),
	(23,NULL,'app','m160804_110002_userphotos_to_assets','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','d421c040-51ca-4ab0-864a-7b9d42777496'),
	(24,NULL,'app','m160807_144858_sites','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','77afd9c3-e21d-41ea-8e05-d6320705f2c5'),
	(25,NULL,'app','m160829_000000_pending_user_content_cleanup','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','877c2064-678f-43ee-8c57-eec2bbf12952'),
	(26,NULL,'app','m160830_000000_asset_index_uri_increase','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','349960c6-4400-4712-9d71-6d39b6be0010'),
	(27,NULL,'app','m160912_230520_require_entry_type_id','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','152352af-202a-4be6-95ca-3d282b26bcf4'),
	(28,NULL,'app','m160913_134730_require_matrix_block_type_id','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','c533d139-e76d-4ff3-9a81-3fe0012affaf'),
	(29,NULL,'app','m160920_174553_matrixblocks_owner_site_id_nullable','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','55935eb3-54e1-4d3d-b379-9c1fd9916151'),
	(30,NULL,'app','m160920_231045_usergroup_handle_title_unique','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','b2f6845f-b196-45e7-9f5d-8a4317591f4b'),
	(31,NULL,'app','m160925_113941_route_uri_parts','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','18dca6a1-4579-4f2b-a4e9-e3f67dc2eca0'),
	(32,NULL,'app','m161006_205918_schemaVersion_not_null','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','cf044af1-ad48-4a56-91ae-6415aa61869f'),
	(33,NULL,'app','m161007_130653_update_email_settings','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','4c25f829-7112-4588-b58f-8681f0985742'),
	(34,NULL,'app','m161013_175052_newParentId','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','eba8e038-7130-477e-b204-24df811a185a'),
	(35,NULL,'app','m161021_102916_fix_recent_entries_widgets','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','3dc415cb-0932-409a-a201-7b2ef11129ed'),
	(36,NULL,'app','m161021_182140_rename_get_help_widget','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','3fbb65fb-6181-4c03-8446-f32739dd2ea9'),
	(37,NULL,'app','m161025_000000_fix_char_columns','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','9a04226e-f1b9-4214-8df4-4b3ded2ffde0'),
	(38,NULL,'app','m161029_124145_email_message_languages','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','0aba7953-32f1-4010-a971-b724a95fe7b9'),
	(39,NULL,'app','m161108_000000_new_version_format','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','f098494e-3028-4fc2-b033-c4cb1afac79a'),
	(40,NULL,'app','m161109_000000_index_shuffle','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','e963bd49-10b7-4153-b2e4-3fc314f92f29'),
	(41,NULL,'app','m161122_185500_no_craft_app','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','b526de5b-3282-4d05-8d34-37b80ce1b469'),
	(42,NULL,'app','m161125_150752_clear_urlmanager_cache','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','81d29112-8261-403d-ab4a-f9eacad34775'),
	(43,NULL,'app','m161220_000000_volumes_hasurl_notnull','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','428a906d-c857-47b2-9bce-ac896b6b30bf'),
	(44,NULL,'app','m170114_161144_udates_permission','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','a2525992-a166-4220-8486-bdaaad647ead'),
	(45,NULL,'app','m170120_000000_schema_cleanup','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','e6c83cbb-3600-45d7-93b0-5b6d663bf38c'),
	(46,NULL,'app','m170126_000000_assets_focal_point','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','2319bc11-be90-4820-9166-66de8f4f3467'),
	(47,NULL,'app','m170206_142126_system_name','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','95f37227-bc2a-49b2-8e67-12eb953b7119'),
	(48,NULL,'app','m170217_044740_category_branch_limits','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','436ee069-5332-418e-a535-06717e84bcb0'),
	(49,NULL,'app','m170217_120224_asset_indexing_columns','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','5b14df9a-4729-404b-8db2-d674269af915'),
	(50,NULL,'app','m170223_224012_plain_text_settings','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','c10a1bab-2b13-4fe6-9ef4-da705b5eff9d'),
	(51,NULL,'app','m170227_120814_focal_point_percentage','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','3e2136da-3d69-4843-9290-4ce6c16b6490'),
	(52,NULL,'app','m170228_171113_system_messages','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','177a07c9-faf5-45c6-a9b1-af68f53b7cdc'),
	(53,NULL,'app','m170303_140500_asset_field_source_settings','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','ec8d405b-a6c4-4577-8937-93b2c01de87a'),
	(54,NULL,'app','m170306_150500_asset_temporary_uploads','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','838dd26e-e478-4e81-ab16-8d403a71a20e'),
	(55,NULL,'app','m170414_162429_rich_text_config_setting','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','e05981cc-75ea-48dd-b797-149a18ec16e8'),
	(56,NULL,'app','m170523_190652_element_field_layout_ids','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','f9964308-2eab-42c1-ba45-511aa172e6b1'),
	(57,NULL,'app','m170612_000000_route_index_shuffle','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','769f7bf9-6c1f-4326-945e-ef9aff805b03'),
	(58,NULL,'app','m170621_195237_format_plugin_handles','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','62c4ec6a-8706-4477-9184-c79f424be314'),
	(59,NULL,'app','m170630_161028_deprecation_changes','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','c72261e5-ad98-4c0f-898b-d50f591a4831'),
	(60,NULL,'app','m170703_181539_plugins_table_tweaks','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','3251b6c6-e765-4655-990b-30a547894cb0'),
	(61,NULL,'app','m170704_134916_sites_tables','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','c5afec8c-3634-468d-8c1a-ad13df9de238'),
	(62,NULL,'app','m170706_183216_rename_sequences','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','d688a39c-0d38-4368-85bf-25f2a2d65ce1'),
	(63,NULL,'app','m170707_094758_delete_compiled_traits','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','1cebd735-6ad1-449b-88e4-d323dfecd16d'),
	(64,NULL,'app','m170731_190138_drop_asset_packagist','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','97cbc34a-ee9b-42ef-960f-054aa51acf87'),
	(65,NULL,'app','m170810_201318_create_queue_table','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','16204973-a0bf-4274-b0da-3d8f7f16edcd'),
	(66,NULL,'app','m170816_133741_delete_compiled_behaviors','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','eba67195-8f1b-4bef-99c0-9c320febd2c4'),
	(67,NULL,'app','m170821_180624_deprecation_line_nullable','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','c879d10e-d3d3-4cf8-bafb-5296c3ba8bad'),
	(68,NULL,'app','m170903_192801_longblob_for_queue_jobs','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','a6882300-5c77-42d2-b3ff-67af33e6b360'),
	(69,NULL,'app','m170914_204621_asset_cache_shuffle','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','b655f491-f369-4d0c-9abd-4fba465e61a5'),
	(70,NULL,'app','m171011_214115_site_groups','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','1e4e9c1e-6e09-474c-9ace-2f3d7ba4f9f3'),
	(71,NULL,'app','m171012_151440_primary_site','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','67fc3f73-f17e-479b-8bf9-c836a294eb43'),
	(72,NULL,'app','m171013_142500_transform_interlace','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','7ab00d82-a0d6-4585-b3eb-462ede51f2a7'),
	(73,NULL,'app','m171016_092553_drop_position_select','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','93532b4d-09cb-4184-a1e9-b4316d4c9151'),
	(74,NULL,'app','m171016_221244_less_strict_translation_method','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','5111c6ae-15d0-4b7e-a48f-bac81b7e46f5'),
	(75,NULL,'app','m171107_000000_assign_group_permissions','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','49239121-f81f-4af5-950b-90247bca9cf0'),
	(76,NULL,'app','m171117_000001_templatecache_index_tune','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','a6447fa6-f857-4785-b69f-5364a9c0b9cb'),
	(77,NULL,'app','m171126_105927_disabled_plugins','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','8c33ecb8-a3e1-4b8a-a8b0-6a4542eb087a'),
	(78,NULL,'app','m171130_214407_craftidtokens_table','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','44483c37-f19a-4ed5-91b4-1bb2efbc6400'),
	(79,NULL,'app','m171202_004225_update_email_settings','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','b9bc5b83-cc03-4d03-a4a4-97cb616d59f0'),
	(80,NULL,'app','m171204_000001_templatecache_index_tune_deux','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','82e7ee8d-0d7a-47a2-9027-8eb43870ea6b'),
	(81,NULL,'app','m171205_130908_remove_craftidtokens_refreshtoken_column','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','4f4cc9ee-6e3f-45f5-8356-36362a52bee6'),
	(82,NULL,'app','m171218_143135_longtext_query_column','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','3107b2a7-b7e6-4c66-a0bf-de4419fe2d8b'),
	(83,NULL,'app','m171231_055546_environment_variables_to_aliases','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','9a60382a-1f09-4a6e-b192-2d1ee3baf1e9'),
	(84,NULL,'app','m180113_153740_drop_users_archived_column','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','5d6d7729-d8c5-4e47-b531-d15c4715fe0f'),
	(85,NULL,'app','m180122_213433_propagate_entries_setting','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','9910b635-c71c-4b2d-acdd-51c82913a5ce'),
	(86,NULL,'app','m180124_230459_fix_propagate_entries_values','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','5bad8b43-0418-4b8c-b225-e5ea7018e272'),
	(87,NULL,'app','m180128_235202_set_tag_slugs','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','e2744d94-8e4f-4515-bcbc-a042507db1f8'),
	(88,NULL,'app','m180202_185551_fix_focal_points','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','81b22c9d-387d-4819-8405-52f6ae9abfcf'),
	(89,NULL,'app','m180217_172123_tiny_ints','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','a4d4beae-5a08-420b-a577-1639a86b5703'),
	(90,NULL,'app','m180321_233505_small_ints','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','8f346bc9-d4d8-47aa-abb0-f3438b03d08c'),
	(91,NULL,'app','m180328_115523_new_license_key_statuses','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','d3c375ab-fd3b-4e21-886f-def99db51f9e'),
	(92,NULL,'app','m180404_182320_edition_changes','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','1e3cae55-8120-4295-bb90-d536b1ad398c'),
	(93,NULL,'app','m180411_102218_fix_db_routes','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','06935f90-601c-44c1-8025-30a8e3d95e97'),
	(94,NULL,'app','m180416_205628_resourcepaths_table','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','6ce4d8f4-8267-4795-a174-8bd045240981'),
	(95,NULL,'app','m180418_205713_widget_cleanup','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','de09e5cf-2c7a-4f73-83f3-6b541f391518'),
	(96,NULL,'app','m180824_193422_case_sensitivity_fixes','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','ed5ae9ec-805e-4856-9325-138abd37fb1f'),
	(97,NULL,'app','m180901_151639_fix_matrixcontent_tables','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','b4dda9bc-d2ef-4c75-9130-4419c8401f10'),
	(98,NULL,'app','m181112_203955_sequences_table','2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-11 18:44:42','5f42584a-e10a-40e4-94d1-9635297eeb02'),
	(99,3,'plugin','m180430_204710_remove_old_plugins','2018-12-13 14:43:15','2018-12-13 14:43:15','2018-12-13 14:43:15','1cc5b235-ce82-499f-af58-ed8295fe43f7'),
	(100,3,'plugin','Install','2018-12-13 14:43:15','2018-12-13 14:43:15','2018-12-13 14:43:15','2858e365-84e6-41bc-827e-235fe4e10c02'),
	(101,4,'plugin','Install','2018-12-13 16:35:58','2018-12-13 16:35:58','2018-12-13 16:35:58','1cfd2daf-c6e3-43f9-b87d-c14ce46d4bdc'),
	(102,4,'plugin','m180210_000000_migrate_content_tables','2018-12-13 16:35:58','2018-12-13 16:35:58','2018-12-13 16:35:58','d5230d92-73a8-47d0-8b2d-50c112e5cae8'),
	(103,4,'plugin','m180211_000000_type_columns','2018-12-13 16:35:58','2018-12-13 16:35:58','2018-12-13 16:35:58','d4c2b323-62f4-4860-9bdb-1cf8c00beed5'),
	(104,4,'plugin','m180219_000000_sites','2018-12-13 16:35:58','2018-12-13 16:35:58','2018-12-13 16:35:58','ad902caf-2db9-4d61-b943-85ae8e229272'),
	(105,4,'plugin','m180220_000000_fix_context','2018-12-13 16:35:58','2018-12-13 16:35:58','2018-12-13 16:35:58','b209a90a-ae61-403c-af92-8a48fb21ae45'),
	(106,5,'plugin','Install','2018-12-13 16:36:02','2018-12-13 16:36:02','2018-12-13 16:36:02','2f8752a4-d8b7-4fe9-a24b-ff1b547a053a');

/*!40000 ALTER TABLE `craft_migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_plugins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_plugins`;

CREATE TABLE `craft_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKey` char(24) DEFAULT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `settings` text,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_plugins_handle_unq_idx` (`handle`),
  KEY `craft_plugins_enabled_idx` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_plugins` WRITE;
/*!40000 ALTER TABLE `craft_plugins` DISABLE KEYS */;

INSERT INTO `craft_plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKey`, `licenseKeyStatus`, `enabled`, `settings`, `installDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'environment-label','3.1.5','1.0.0',NULL,'unknown',1,NULL,'2018-12-11 21:53:20','2018-12-11 21:53:20','2018-12-14 21:20:56','268e2860-084e-4e14-94e0-4c8e79228393'),
	(2,'assetrev','6.0.2','1.0.0',NULL,'unknown',1,NULL,'2018-12-11 21:58:25','2018-12-11 21:58:25','2018-12-14 21:20:56','f91ff52d-666c-48cd-9900-d8cf76203c64'),
	(3,'redactor','2.1.6','2.0.0',NULL,'unknown',1,NULL,'2018-12-13 14:43:15','2018-12-13 14:43:15','2018-12-14 21:20:56','3cc110e0-e59e-435e-b3c8-e24a55544266'),
	(4,'super-table','2.0.14','2.0.4',NULL,'unknown',1,NULL,'2018-12-13 16:35:58','2018-12-13 16:35:58','2018-12-14 21:20:56','6a1d73eb-9360-4222-84c1-c2418cea4931'),
	(5,'spoon','3.2.4','3.0.0',NULL,'invalid',1,NULL,'2018-12-13 16:36:02','2018-12-13 16:36:02','2018-12-14 21:20:56','019984c1-f0bd-467a-a794-9571af565173'),
	(6,'twig-perversion','2.0.6','1.0.0',NULL,'unknown',1,NULL,'2018-12-14 21:20:45','2018-12-14 21:20:45','2018-12-14 21:20:56','88bbac25-bba0-4420-b0eb-af9bf19c4a3a');

/*!40000 ALTER TABLE `craft_plugins` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_queue
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_queue`;

CREATE TABLE `craft_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `craft_queue_fail_timeUpdated_timePushed_idx` (`fail`,`timeUpdated`,`timePushed`),
  KEY `craft_queue_fail_timeUpdated_delay_idx` (`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_relations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_relations`;

CREATE TABLE `craft_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `craft_relations_sourceId_idx` (`sourceId`),
  KEY `craft_relations_targetId_idx` (`targetId`),
  KEY `craft_relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `craft_relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_relations` WRITE;
/*!40000 ALTER TABLE `craft_relations` DISABLE KEYS */;

INSERT INTO `craft_relations` (`id`, `fieldId`, `sourceId`, `sourceSiteId`, `targetId`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(13,67,7,NULL,3,1,'2018-12-15 00:09:32','2018-12-15 00:09:32','c655d9f8-19d9-4c29-97af-cc9e33dee71e'),
	(14,67,8,NULL,3,1,'2018-12-15 00:09:32','2018-12-15 00:09:32','7f19db83-8a52-4250-ae41-b663755177e3'),
	(15,67,9,NULL,2,1,'2018-12-15 00:09:32','2018-12-15 00:09:32','d21efac9-5705-4dd2-9f45-9d9e42423b02');

/*!40000 ALTER TABLE `craft_relations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_resourcepaths
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_resourcepaths`;

CREATE TABLE `craft_resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_resourcepaths` WRITE;
/*!40000 ALTER TABLE `craft_resourcepaths` DISABLE KEYS */;

INSERT INTO `craft_resourcepaths` (`hash`, `path`)
VALUES
	('17d48c31','@lib/timepicker'),
	('1fde4875','@app/web/assets/plugins/dist'),
	('224790ce','@lib/selectize'),
	('2317221f','@app/web/assets/pluginstoreoauth/dist'),
	('2468b587','@craft/web/assets/cp/dist'),
	('282bd444','@lib/xregexp'),
	('2914ee51','@craft/web/assets/installer/dist'),
	('2d1385fa','@craft/web/assets/pluginstore/dist'),
	('2e20b196','@vendor/craftcms/redactor/lib/redactor'),
	('3e166c16','@craft/web/assets/updateswidget/dist'),
	('4b218a9d','@lib/garnishjs'),
	('537a2c16','@craft/redactor/assets/field/dist'),
	('5a722b28','@app/web/assets/fields/dist'),
	('5d150566','@app/web/assets/dashboard/dist'),
	('5e675ea3','@lib/fabric'),
	('5ea2974e','@craft/web/assets/fields/dist'),
	('625d8a45','@app/web/assets/dbbackup/dist'),
	('6ed1bcb4','@lib/fileupload'),
	('719d8188','@lib/jquery-touch-events'),
	('7291e552','@app/web/assets/matrix/dist'),
	('7639bd4a','@lib/picturefill'),
	('76415934','@craft/web/assets/matrix/dist'),
	('76b0253b','@craft/web/assets/tablesettings/dist'),
	('789c9d1b','@lib/d3'),
	('7db3c766','@app/web/assets/editentry/dist'),
	('7e9a8d4d','@craft/web/assets/utilities/dist'),
	('83556ca7','@app/web/assets/recententries/dist'),
	('85200601','@app/web/assets/pluginstore/dist'),
	('855d6fcc','@verbb/supertable/resources/dist'),
	('91bc2dd2','@craft/web/assets/login/dist'),
	('96f6827','@craft/web/assets/updater/dist'),
	('99ba9a1f','@craft/web/assets/craftsupport/dist'),
	('9a265e54','@app/web/assets/login/dist'),
	('9e184b2a','@app/web/assets/cp/dist'),
	('a5b5ed15','@lib/jquery-ui'),
	('a6afa75b','@craft/web/assets/feed/dist'),
	('ac2e78','@craft/web/assets/recententries/dist'),
	('adba7cf6','@app/web/assets/updater/dist'),
	('b37d8208','@app/web/assets/craftsupport/dist'),
	('bb0b5ca4','@craft/web/assets/plugins/dist'),
	('bdef2ec9','@app/web/assets/updateswidget/dist'),
	('c02662fc','@craft/web/assets/matrixsettings/dist'),
	('c2b94035','@lib'),
	('d5032a38','@lib/element-resize-detector'),
	('d6c954fb','@app/web/assets/matrixsettings/dist'),
	('dfec8190','@craft/web/assets/dashboard/dist'),
	('e7030094','@app/web/assets/feed/dist'),
	('eb1c76b0','@lib/velocity'),
	('f310377b','@craft/web/assets/editcategory/dist'),
	('f417e5e8','@angellco/spoon/assetbundles/dist'),
	('f54967e4','@app/web/assets/tablesettings/dist'),
	('f73bd958','@lib/jquery.payment'),
	('fa9381cd','@bower/jquery/dist'),
	('fc6309bb','@app/web/assets/utilities/dist'),
	('ff4a4390','@craft/web/assets/editentry/dist');

/*!40000 ALTER TABLE `craft_resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_routes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_routes`;

CREATE TABLE `craft_routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) DEFAULT NULL,
  `uriParts` varchar(255) NOT NULL,
  `uriPattern` varchar(255) NOT NULL,
  `template` varchar(500) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_routes_uriPattern_idx` (`uriPattern`),
  KEY `craft_routes_siteId_idx` (`siteId`),
  CONSTRAINT `craft_routes_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_searchindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_searchindex`;

CREATE TABLE `craft_searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `craft_searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `craft_searchindex` WRITE;
/*!40000 ALTER TABLE `craft_searchindex` DISABLE KEYS */;

INSERT INTO `craft_searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`)
VALUES
	(1,'username',0,1,' admin '),
	(1,'firstname',0,1,''),
	(1,'lastname',0,1,''),
	(1,'fullname',0,1,''),
	(1,'email',0,1,' fed viget com '),
	(1,'slug',0,1,''),
	(2,'slug',0,1,' full '),
	(2,'title',0,1,' full '),
	(3,'slug',0,1,' 1 2 '),
	(3,'title',0,1,' 1 2 '),
	(4,'field',2,1,''),
	(4,'field',1,1,''),
	(4,'field',4,1,''),
	(4,'field',3,1,''),
	(4,'field',8,1,' left side 1 2 right side 1 2 all of it full '),
	(6,'field',9,1,' left side 1 2 right side 1 2 all of it full '),
	(7,'field',66,1,' left side '),
	(7,'field',67,1,' 1 2 '),
	(7,'slug',0,1,''),
	(8,'field',66,1,' right side '),
	(8,'field',67,1,' 1 2 '),
	(8,'slug',0,1,''),
	(9,'field',66,1,' all of it '),
	(9,'field',67,1,' full '),
	(9,'slug',0,1,''),
	(6,'slug',0,1,''),
	(4,'slug',0,1,' gregs entry '),
	(4,'title',0,1,' test entry ');

/*!40000 ALTER TABLE `craft_searchindex` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sections`;

CREATE TABLE `craft_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagateEntries` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_handle_unq_idx` (`handle`),
  UNIQUE KEY `craft_sections_name_unq_idx` (`name`),
  KEY `craft_sections_structureId_idx` (`structureId`),
  CONSTRAINT `craft_sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sections` WRITE;
/*!40000 ALTER TABLE `craft_sections` DISABLE KEYS */;

INSERT INTO `craft_sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagateEntries`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,'Callouts','callouts','channel',1,1,'2018-12-13 17:25:54','2018-12-13 17:29:44','d484ec61-6a32-4c1a-9206-fea166f81a7f'),
	(2,1,'Products','products','structure',1,1,'2018-12-13 17:41:54','2018-12-14 22:03:38','cd88355d-0a43-47f5-9217-34b414ec5f64'),
	(3,NULL,'CTAs','ctas','channel',1,1,'2018-12-13 17:47:38','2018-12-13 17:47:38','1dc888e1-7284-42ba-8511-f1ea73bdfe83'),
	(4,2,'Solutions','solutions','structure',1,1,'2018-12-13 17:53:19','2018-12-14 22:03:51','0fcce066-62f0-4b14-b828-2840126e0fce'),
	(5,NULL,'Logos','logos','channel',1,1,'2018-12-13 21:40:22','2018-12-13 21:40:22','53ce69e4-7b06-4ee1-9f13-8c927fccd624'),
	(6,NULL,'Related Products','relatedProducts','channel',1,1,'2018-12-13 21:43:32','2018-12-13 23:29:35','ba27ea6b-4d77-4123-9531-b8de129f6bf9');

/*!40000 ALTER TABLE `craft_sections` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sections_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sections_sites`;

CREATE TABLE `craft_sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `craft_sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `craft_sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sections_sites` WRITE;
/*!40000 ALTER TABLE `craft_sections_sites` DISABLE KEYS */;

INSERT INTO `craft_sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,0,NULL,NULL,1,'2018-12-13 17:25:54','2018-12-13 17:29:44','eb715e13-6bda-43c6-aa8e-298260f742e3'),
	(2,2,1,1,'products/{slug}','_products/product',1,'2018-12-13 17:41:54','2018-12-14 22:03:38','b0d7c25b-1328-44c1-b7ec-49bf5988fa4f'),
	(3,3,1,0,NULL,NULL,1,'2018-12-13 17:47:38','2018-12-13 17:47:38','b2d6710d-5d15-422c-9599-30e59c16851a'),
	(4,4,1,1,'solutions/{slug}','_solutions/solution',1,'2018-12-13 17:53:19','2018-12-14 22:03:51','85f46853-5c2d-4f46-9756-c4d7f00695bf'),
	(5,5,1,0,NULL,NULL,1,'2018-12-13 21:40:22','2018-12-13 21:40:22','de980236-0433-46e1-9024-4de5dca6bdcc'),
	(6,6,1,0,NULL,NULL,1,'2018-12-13 21:43:32','2018-12-13 23:29:35','3b4680b2-117c-4c65-9111-2bf012f8e916');

/*!40000 ALTER TABLE `craft_sections_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sequences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sequences`;

CREATE TABLE `craft_sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sessions`;

CREATE TABLE `craft_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sessions_uid_idx` (`uid`),
  KEY `craft_sessions_token_idx` (`token`),
  KEY `craft_sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `craft_sessions_userId_idx` (`userId`),
  CONSTRAINT `craft_sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sessions` WRITE;
/*!40000 ALTER TABLE `craft_sessions` DISABLE KEYS */;

INSERT INTO `craft_sessions` (`id`, `userId`, `token`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(3,1,'aZ1b-_M_LG4NiT9bQTDxqpT5_zOj4FW_5oUT5vmt1HkxCWool5-3QiUGrnTn-VprjPUlmRPp-XeYLJGSVAp5tehxERbnF0b6U5ny','2018-12-15 00:09:14','2018-12-15 00:10:09','844458ca-0dff-445b-b022-25b123fc5888');

/*!40000 ALTER TABLE `craft_sessions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_shunnedmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_shunnedmessages`;

CREATE TABLE `craft_shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `craft_shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_sitegroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sitegroups`;

CREATE TABLE `craft_sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sitegroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sitegroups` WRITE;
/*!40000 ALTER TABLE `craft_sitegroups` DISABLE KEYS */;

INSERT INTO `craft_sitegroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'FiscalNote','2018-12-11 18:44:42','2018-12-11 18:44:42','b12f6396-f4b1-4cf5-bcef-4a46e041e556');

/*!40000 ALTER TABLE `craft_sitegroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sites`;

CREATE TABLE `craft_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sites_handle_unq_idx` (`handle`),
  KEY `craft_sites_sortOrder_idx` (`sortOrder`),
  KEY `craft_sites_groupId_fk` (`groupId`),
  CONSTRAINT `craft_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sites` WRITE;
/*!40000 ALTER TABLE `craft_sites` DISABLE KEYS */;

INSERT INTO `craft_sites` (`id`, `groupId`, `primary`, `name`, `handle`, `language`, `hasUrls`, `baseUrl`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,'FiscalNote','default','en-US',1,'https://fiscalnote.com/',1,'2018-12-11 18:44:42','2018-12-11 18:44:42','66dd9460-ab78-419e-bfb8-0614a22c43f5');

/*!40000 ALTER TABLE `craft_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_spoon_blocktypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_spoon_blocktypes`;

CREATE TABLE `craft_spoon_blocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `matrixBlockTypeId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `groupName` varchar(255) NOT NULL DEFAULT '',
  `context` varchar(255) NOT NULL DEFAULT '',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_spoon_blocktypes_fieldId_idx` (`fieldId`),
  KEY `craft_spoon_blocktypes_matrixBlockTypeId_idx` (`matrixBlockTypeId`),
  KEY `craft_spoon_blocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_spoon_blocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_spoon_blocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_spoon_blocktypes_matrixBlockTypeId_fk` FOREIGN KEY (`matrixBlockTypeId`) REFERENCES `craft_matrixblocktypes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_stc_12_items
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_stc_12_items`;

CREATE TABLE `craft_stc_12_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_heading` text,
  `field_description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_stc_12_items_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_stc_12_items_siteId_fk` (`siteId`),
  CONSTRAINT `craft_stc_12_items_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_stc_12_items_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_stc_13_items
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_stc_13_items`;

CREATE TABLE `craft_stc_13_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_stc_13_items_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_stc_13_items_siteId_fk` (`siteId`),
  CONSTRAINT `craft_stc_13_items_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_stc_13_items_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_stc_pagesections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_stc_pagesections`;

CREATE TABLE `craft_stc_pagesections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_stc_pagesections_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_stc_pagesections_siteId_fk` (`siteId`),
  CONSTRAINT `craft_stc_pagesections_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_stc_pagesections_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_stc_pagesections` WRITE;
/*!40000 ALTER TABLE `craft_stc_pagesections` DISABLE KEYS */;

INSERT INTO `craft_stc_pagesections` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,6,1,'2018-12-14 21:59:37','2018-12-15 00:09:32','e100bc6f-45a3-4ffb-864c-1b3eb8a42dcd');

/*!40000 ALTER TABLE `craft_stc_pagesections` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_stc_productintroductionproducts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_stc_productintroductionproducts`;

CREATE TABLE `craft_stc_productintroductionproducts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_stc_productintroductionproducts_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_stc_productintroductionproducts_siteId_fk` (`siteId`),
  CONSTRAINT `craft_stc_productintroductionproducts_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_stc_productintroductionproducts_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_structureelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_structureelements`;

CREATE TABLE `craft_structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `craft_structureelements_root_idx` (`root`),
  KEY `craft_structureelements_lft_idx` (`lft`),
  KEY `craft_structureelements_rgt_idx` (`rgt`),
  KEY `craft_structureelements_level_idx` (`level`),
  KEY `craft_structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `craft_structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_structureelements` WRITE;
/*!40000 ALTER TABLE `craft_structureelements` DISABLE KEYS */;

INSERT INTO `craft_structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,3,NULL,1,1,6,0,'2018-12-13 21:37:54','2018-12-13 21:37:59','11bf546f-7a59-4bcc-bb94-3e8448fe895a'),
	(2,3,2,1,2,3,1,'2018-12-13 21:37:54','2018-12-13 21:37:54','4f8f64c2-22f5-4de0-9013-b76ea8bc3011'),
	(3,3,3,1,4,5,1,'2018-12-13 21:37:59','2018-12-13 21:37:59','1f378aeb-3b34-40a1-8ed4-d658a66f6844'),
	(4,1,NULL,4,1,4,0,'2018-12-14 21:59:37','2018-12-14 21:59:37','8917783a-5894-4f4e-a274-05bf1dda626f'),
	(5,1,4,4,2,3,1,'2018-12-14 21:59:37','2018-12-14 21:59:37','52e6bee6-1542-47bf-ac95-2aa5aa75fe21');

/*!40000 ALTER TABLE `craft_structureelements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_structures
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_structures`;

CREATE TABLE `craft_structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_structures` WRITE;
/*!40000 ALTER TABLE `craft_structures` DISABLE KEYS */;

INSERT INTO `craft_structures` (`id`, `maxLevels`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,'2018-12-13 17:41:54','2018-12-14 22:03:38','e6c3ad73-02c6-4a61-8b0b-fc2aeca87671'),
	(2,NULL,'2018-12-13 17:53:19','2018-12-14 22:03:51','b08099e1-9485-44a7-b7c9-31d0f6744228'),
	(3,1,'2018-12-13 21:37:34','2018-12-13 21:37:34','76271aa3-6673-4f87-9c19-9688ac6af946');

/*!40000 ALTER TABLE `craft_structures` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_supertableblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_supertableblocks`;

CREATE TABLE `craft_supertableblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_supertableblocks_ownerId_idx` (`ownerId`),
  KEY `craft_supertableblocks_fieldId_idx` (`fieldId`),
  KEY `craft_supertableblocks_typeId_idx` (`typeId`),
  KEY `craft_supertableblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `craft_supertableblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_supertableblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_supertableblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_supertableblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_supertableblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_supertableblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_supertableblocks` WRITE;
/*!40000 ALTER TABLE `craft_supertableblocks` DISABLE KEYS */;

INSERT INTO `craft_supertableblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(6,4,NULL,8,1,1,'2018-12-14 21:59:37','2018-12-15 00:09:32','f75ea604-fbcc-4c09-93dd-79a4bf3dc353');

/*!40000 ALTER TABLE `craft_supertableblocks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_supertableblocktypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_supertableblocktypes`;

CREATE TABLE `craft_supertableblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_supertableblocktypes_fieldId_idx` (`fieldId`),
  KEY `craft_supertableblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_supertableblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_supertableblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_supertableblocktypes` WRITE;
/*!40000 ALTER TABLE `craft_supertableblocktypes` DISABLE KEYS */;

INSERT INTO `craft_supertableblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,8,2,'2018-12-13 17:12:09','2018-12-14 21:58:45','69175300-7f8a-4db6-ac45-c570dbdd1fb2'),
	(3,50,24,'2018-12-13 23:15:32','2018-12-13 23:15:33','341f946a-0d8e-4494-a7a4-aa11340860d9'),
	(4,58,25,'2018-12-13 23:24:22','2018-12-13 23:25:48','45aa9cf0-85b2-4d9a-9ab7-2643cbd3015c'),
	(5,62,27,'2018-12-13 23:24:23','2018-12-13 23:25:48','8310e877-433b-4004-a429-2cb3c36a0c42');

/*!40000 ALTER TABLE `craft_supertableblocktypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_systemmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_systemmessages`;

CREATE TABLE `craft_systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `craft_systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_systemsettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_systemsettings`;

CREATE TABLE `craft_systemsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(15) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_systemsettings_category_unq_idx` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_systemsettings` WRITE;
/*!40000 ALTER TABLE `craft_systemsettings` DISABLE KEYS */;

INSERT INTO `craft_systemsettings` (`id`, `category`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'email','{\"fromEmail\":\"fed@viget.com\",\"fromName\":\"FiscalNote\",\"transportType\":\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"}','2018-12-11 18:44:42','2018-12-11 18:44:42','157654cb-4252-4664-98d8-0dc4a62f910c');

/*!40000 ALTER TABLE `craft_systemsettings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_taggroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_taggroups`;

CREATE TABLE `craft_taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_taggroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_taggroups_handle_unq_idx` (`handle`),
  KEY `craft_taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_tags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tags`;

CREATE TABLE `craft_tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_tags_groupId_idx` (`groupId`),
  CONSTRAINT `craft_tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_tags_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_templatecacheelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecacheelements`;

CREATE TABLE `craft_templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `craft_templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `craft_templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `craft_templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_templatecachequeries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecachequeries`;

CREATE TABLE `craft_templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `craft_templatecachequeries_type_idx` (`type`),
  CONSTRAINT `craft_templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_templatecaches
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecaches`;

CREATE TABLE `craft_templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `craft_templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `craft_templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `craft_templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tokens`;

CREATE TABLE `craft_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_tokens_token_unq_idx` (`token`),
  KEY `craft_tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_usergroups`;

CREATE TABLE `craft_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_handle_unq_idx` (`handle`),
  UNIQUE KEY `craft_usergroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_usergroups_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_usergroups_users`;

CREATE TABLE `craft_usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `craft_usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `craft_usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_userpermissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions`;

CREATE TABLE `craft_userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_userpermissions_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions_usergroups`;

CREATE TABLE `craft_userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `craft_userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `craft_userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_userpermissions_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions_users`;

CREATE TABLE `craft_userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `craft_userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `craft_userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_userpreferences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpreferences`;

CREATE TABLE `craft_userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `craft_userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_userpreferences` WRITE;
/*!40000 ALTER TABLE `craft_userpreferences` DISABLE KEYS */;

INSERT INTO `craft_userpreferences` (`userId`, `preferences`)
VALUES
	(1,'{\"language\":\"en-US\"}');

/*!40000 ALTER TABLE `craft_userpreferences` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_users`;

CREATE TABLE `craft_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_users_uid_idx` (`uid`),
  KEY `craft_users_verificationCode_idx` (`verificationCode`),
  KEY `craft_users_email_idx` (`email`),
  KEY `craft_users_username_idx` (`username`),
  KEY `craft_users_photoId_fk` (`photoId`),
  CONSTRAINT `craft_users_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `craft_assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_users` WRITE;
/*!40000 ALTER TABLE `craft_users` DISABLE KEYS */;

INSERT INTO `craft_users` (`id`, `username`, `photoId`, `firstName`, `lastName`, `email`, `password`, `admin`, `locked`, `suspended`, `pending`, `lastLoginDate`, `lastLoginAttemptIp`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `hasDashboard`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'admin',NULL,NULL,NULL,'fed@viget.com','$2y$13$fS6IRVaALv3Vniyma1se8uL94pamyEDqutERv28wTYlTMN97KX6SS',1,0,0,0,'2018-12-15 00:09:14','::1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2018-12-11 18:44:42','2018-12-11 18:44:42','2018-12-15 00:09:14','33ae99bb-8c5e-4450-af8e-a58293684158');

/*!40000 ALTER TABLE `craft_users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_volumefolders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_volumefolders`;

CREATE TABLE `craft_volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `craft_volumefolders_parentId_idx` (`parentId`),
  KEY `craft_volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `craft_volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_volumes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_volumes`;

CREATE TABLE `craft_volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_volumes_name_unq_idx` (`name`),
  UNIQUE KEY `craft_volumes_handle_unq_idx` (`handle`),
  KEY `craft_volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_widgets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_widgets`;

CREATE TABLE `craft_widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(1) NOT NULL DEFAULT '0',
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_widgets_userId_idx` (`userId`),
  CONSTRAINT `craft_widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_widgets` WRITE;
/*!40000 ALTER TABLE `craft_widgets` DISABLE KEYS */;

INSERT INTO `craft_widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'craft\\widgets\\RecentEntries',1,0,'{\"section\":\"*\",\"siteId\":\"1\",\"limit\":10}',1,'2018-12-11 18:46:51','2018-12-11 18:46:51','a0bb444c-1af0-457d-ae7b-46b85769bbd8'),
	(2,1,'craft\\widgets\\CraftSupport',2,0,'[]',1,'2018-12-11 18:46:51','2018-12-11 18:46:51','6b79e673-be3f-4a15-bda3-6b120da6ba4f'),
	(3,1,'craft\\widgets\\Updates',3,0,'[]',1,'2018-12-11 18:46:51','2018-12-11 18:46:51','74e2c715-d044-4ee6-ab17-97abc2324dfb'),
	(4,1,'craft\\widgets\\Feed',4,0,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2018-12-11 18:46:51','2018-12-11 18:46:51','1b82df03-ff13-4ff8-8828-0967ce4d932a');

/*!40000 ALTER TABLE `craft_widgets` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
